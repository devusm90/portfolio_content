import BottomNav from "@components/BottomNav";
import Container from "@components/Container";
import React, { useState } from "react";
import { Alert, Dimensions, Image, Modal, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";

const width = Dimensions.get("window").width; //full width
// eslint-disable-next-line no-unused-vars, @typescript-eslint/no-unused-vars, @typescript-eslint/no-explicit-any
export default function Profile({ navigation }: { navigation: any }) {


  const [modalVisible, setModalVisible] = useState(false);
  const [profile,setProfile] = useState(null);

 

  const changeImage = () =>{
    alert("hi");
  }

  return (
    <Container>
      <ScrollView contentContainerStyle={styles.scrollview}>
        <View style={styles.profileimg}>

        <Pressable style={styles.profileimage}>
          <Image
              style={styles.userImage}
              source={require("@assets/images/user_img.png")}
            />
            <Image
              style={styles.editbtn}
              source={require("@assets/images/edit.png")}
            />
        </Pressable>
            <Text style={styles.userName}>Maalty</Text>


            {/* <Text style={styles.leveltext}>Level 3</Text> */}
            <View><Image
            style={styles.yeloline}
            source={require("@assets/images/yellow-line.png")}
          /></View>
        

        </View>

        {/* <Image
            style={styles.enthuimg}
            source={require("@assets/images/enthusiast.png")}
          />
          <Text style={styles.enthutext}>Enthusiast</Text> */}

          <View style={styles.selectwrap}>
            <Text style={styles.seletext}>Course Opted</Text>
            <Text style={styles.jeetext}>JEE</Text>
            <Image
            style={styles.downarrow}
            source={require("@assets/images/downarrow.png")}
            />
            
          </View>

          <View style={styles.selectwrap}>
            <Text style={styles.statustext}>Status</Text>
            <View>
              <Text style={styles.pretext}>Premium User</Text>
              <Text style={styles.days}>43 Days Left</Text>
            </View>
          </View>

          <View style={styles.budgwrap}>
            <Text style={styles.budgtitle}>My Badges</Text>

            <View style={styles.bdgrow}>
              <View style={styles.bdgcol}>
                <Image
                  style={styles.enthuimg}
                  source={require("@assets/images/enthusiast.png")}
                />
                <Text style={styles.bdglev}>Level 1</Text>
              </View>
              <View style={styles.bdgcol}>
                <Image
                  style={styles.enthuimg}
                  source={require("@assets/images/enthusiast2.png")}
                />
                <Text style={styles.bdglev}>Level 2</Text>
              </View>
              <View style={styles.bdgcol}>
                <Image
                  style={styles.enthuimg}
                  source={require("@assets/images/enthusiast3.png")}
                />
                <Text style={styles.bdglev}>Level 3</Text>
              </View>
              <View style={styles.bdgcol}>
                <Image
                  style={styles.enthuimg}
                  source={require("@assets/images/enthusiast4.png")}
                />
                <Text style={styles.bdglev}>Level 4</Text>
              </View>
            </View>
            <Pressable style={styles.seewrap} onPress={() => navigation.navigate("ProfileAll")}>
            <Text style={styles.seeall}>See All</Text>
            <Image
              style={styles.forward}
              source={require("@assets/images/forward.png")}
            />
            </Pressable>
          </View>

          <View style={styles.profcom}>

          <View style={styles.titwrap}>
            <View>
              <Text style={styles.prftitle}>Profile Completion</Text>
            </View>
            <View>
              <View style={styles.greybar}>
                <View style={styles.barfill}></View>
              </View>
            </View>
            <Text style={styles.perstext}>60%</Text>
          </View>
          <View style={styles.line}></View>
          <Text style={styles.actdetails}>Account Details</Text>

          <View style={styles.detilwrap}>
            <Image
              style={styles.deficon}
              source={require("@assets/images/phone.png")}
            />
            <Text style={styles.detiltext}>+91 8038035555</Text>
          </View>
          <Text style={styles.prfdetails}>Profile Details</Text>

          <View style={styles.detilwrap}>
            <Image style={styles.deficon} source={require("@assets/images/usericn.png")} />
            <Text style={styles.detiltext}>Maalty</Text>
          </View>
          <View style={styles.detilwrap}>
            <Image style={styles.deficon} source={require("@assets/images/mailicn.png")} />
            <Text style={styles.detiltext}>maaltykutty@gmail.com</Text>
          </View>
          <View style={styles.detilwrap}>
            <Image style={styles.deficon} source={require("@assets/images/gender.png")} />
            <Text style={styles.detiltext}>Female</Text>
          </View>
          <View style={styles.detilwrap}>
            <Image style={styles.deficon} source={require("@assets/images/locicon.png")} />
            <Text style={styles.detiltext}>Location</Text>
          </View>
          <View style={styles.detilwrap}>
            <Image style={styles.deficon} source={require("@assets/images/birth.png")} />
            <Text style={styles.detiltext}>Your Birthday</Text>
          </View>


          
        </View>


        <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          Alert.alert('Modal has been closed.');
          setModalVisible(!modalVisible);
        }}>
        <View style={styles.centeredView}>



<View style={styles.modelView}>

<View style={styles.row}>
  <Text style={styles.modelTitle}>Choose your Avatar</Text>
  <Pressable style={styles.modalcls} onPress={() => setModalVisible(!modalVisible)}>
    <Image style={styles.clsebtn} source={require("@assets/images/close2.png")} />
  </Pressable>
</View>

<View style={styles.userrow}>
  <Pressable onPress={changeImage} style={styles.imgwrap}>
      <Image style={styles.usrimg} source={require("@assets/images/user1.png")} />
  </Pressable>
  <Pressable onPress={changeImage} style={styles.imgwrap}>
      <Image style={styles.usrimg} source={require("@assets/images/user2.png")} />
  </Pressable>
  <Pressable onPress={changeImage} style={styles.imgwrap}>
      <Image style={styles.usrimg} source={require("@assets/images/user3.png")} />
  </Pressable>
  <Pressable onPress={changeImage} style={styles.imgwrap}>
      <Image style={styles.usrimg} source={require("@assets/images/user4.png")} />
  </Pressable>
  <Pressable onPress={changeImage} style={styles.imgwrap}>
      <Image style={styles.usrimg} source={require("@assets/images/user5.png")} />
  </Pressable>
  <Pressable onPress={changeImage} style={styles.imgwrap}>
      <Image style={styles.usrimg} source={require("@assets/images/user6.png")} />
  </Pressable>
  <Pressable onPress={changeImage} style={styles.imgwrap}>
      <Image style={styles.usrimg} source={require("@assets/images/user7.png")} />
  </Pressable>
  <Pressable onPress={changeImage} style={styles.imgwrap}>
      <Image style={styles.usrimg} source={require("@assets/images/user8.png")} />
  </Pressable>
  <Pressable onPress={changeImage} style={styles.imgwrap}>
      <Image style={styles.usrimg} source={require("@assets/images/user9.png")} />
  </Pressable>
</View>


<View style={styles.uplodrow}>
  <Pressable style={styles.uploadBtn}>
    <Image style={styles.uplodimg} source={require("@assets/images/upload.png")} />
    <Text style={styles.uplodtext}>Upload</Text>
  </Pressable>

  <Pressable style={styles.btn}>
    <Text style={styles.btnText}>Confirm</Text>
  </Pressable>
</View>



</View>
          
        </View>
      </Modal>


 
      </ScrollView>
      <BottomNav />
    </Container>
  );
}

const styles = StyleSheet.create({

  centeredView:{
    backgroundColor:'#0e0f1be6',
    padding:20,
    flex:1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modelView:{
    backgroundColor:'#18191C',
    padding:20,
    width:width-40,
    borderRadius:20,

  },
  clsebtn:{
    width: 20,
    height: 20,
    marginLeft:'auto',
  },
  row:{
    flexDirection: "row",
    justifyContent: "space-between",
  },
  modelTitle:{
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 18,
    marginBottom:10 ,
  },
  usrimg:{
    width:70,
    height:70,

  },
  uplodrow:{
    flexDirection:"row",
    justifyContent:"space-between",
    padding:20,
    paddingBottom:0,
  },
  userrow:{
    flexDirection: "row",
    justifyContent: "space-between",
    flexWrap:'wrap',
    paddingTop:10,
  },
  imgwrap:{
    padding:8,
  },
  uploadBtn:{
    flexDirection:"row",
    paddingTop:8,
  },
  uplodimg:{
    width:22,
    height:24,
  },
  uplodtext:{
    color:'#777BD1',
    fontFamily: "PoppinsSemiBold",
    fontSize:16,
    paddingLeft:6,
  },







  btn: {
    backgroundColor: "#787bd1",
    height: 40,
    width:100,
    borderRadius: 12,
    textAlign: "center",
  },
  btnText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "bold",
    paddingTop: 8,
  },





  actdetails:{
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 16,
    marginBottom:10 ,
  },
  prfdetails:{
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    marginTop:10,
    fontSize: 16,
    marginBottom:16 ,
  },
  detilwrap:{
    position:'relative',
    marginBottom:12,
  },
  detiltext:{
    fontFamily: "PoppinsRegular",
    color: "#FFF1E4",
    fontSize: 14,
    position:'relative',
    paddingLeft:36,
  },
  deficon:{
    width:20,
    height:20,
    position:'absolute',
    top:0,
    left:0


    
  },

  userImage:{
    width:80,
    height:80,
  },
  profileimage:{
    position:"relative"
  },
  editbtn:{
    position:"absolute",
    left:33,
    right:0,
    bottom:-7
  },
  userName:{
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 24,
    textAlign: "center",
    marginBottom: 3,
    paddingTop:16,
  },
  leveltext:{
    fontFamily: "RobotoRegular",
    color: "#FFF1E4",
    fontSize: 16,
    textAlign: "center", 
    opacity:.7,
  },
  yeloline: {
    width: 60,
    height: 4,
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 6,
    marginBottom:20
  },
  enthuimg:{
    width: 50,
    height: 50,
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 20,
  },
  enthutext:{
    fontFamily: "RecoletaMedium",
    color: "#FFF1E4",
    fontSize: 18,
    textAlign: "center",
    paddingTop:10,
    marginBottom:20,
  },
  selectwrap:{
    backgroundColor:'#18191C',
    marginLeft:20,
    marginRight:20,
    borderRadius:12,
    padding:16,
    paddingLeft:20,
    paddingRight:28,
    marginBottom:20,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  seletext:{
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 16,
  },
  statustext:{
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 16,
    paddingTop:8,
  },
  jeetext:{
    fontFamily: "RobotoRegular",
    color: "#FFF1E4",
    fontSize: 12,
    textAlign: "center", 
    opacity:.7,
  },
  downarrow:{
    width:16,
    height:8,
    marginTop:8,
  },
  pretext:{
    fontFamily: "RecoletaMedium",
    color: "#62D4A1",
    fontSize: 14,
    textAlign: "center",
  },
  days:{
    fontFamily: "RobotoRegular",
    color: "#FFF1E4",
    fontSize: 14,
    textAlign: "center", 
    opacity:.7,
  },
  budgwrap:{
    backgroundColor:'#18191C',
    padding:20,
    paddingTop:4,
    marginLeft:20,
    marginRight:20,
    borderRadius:12,

  },
  budgtitle:{
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 20,
    paddingTop:8,
  },
  bdgrow:{
    flexDirection: "row",
    justifyContent: "space-between",

  },
  bdgcol:{
    padding:2,
  },
  bdglev:{
    fontFamily: "PoppinsRegular",
    color: "#FFF1E4",
    fontSize: 12,
    textAlign: "center", 
    opacity:.7,
    paddingTop:4,
  },
  seewrap:{
    flexDirection: "row",
  },
  seeall:{
    fontFamily: "PoppinsSemiBold",
    color:'#777BD1',
    fontSize:14,
    paddingTop:4,
    paddingLeft:12,
  },
  forward:{
    width:8,
    height:14,
    marginTop:7,
    marginLeft:12,

  },
  prftitle:{
    fontFamily: "PoppinsSemiBold",
    color:'#FFF1E4',
    fontSize:14,
  },
  perstext:{
    fontFamily: "PoppinsSemiBold",
    color:'#FFF1E4',
    fontSize:14,
  },
  titwrap:{
    flexDirection:'row',
    justifyContent:'space-between'

  },
  profcom:{
    backgroundColor:'#18191C',
    padding:20,
    marginLeft:20,
    marginRight:20,
    marginTop:20,
    borderRadius:12,
  },

  profileimg:{
    marginLeft:'auto',
    marginRight:'auto',
    paddingTop:80,

  },
  greybar: {
    backgroundColor: "#4E4B66",
    marginLeft: 20,
    borderRadius: 4,
    width:90,
    marginTop:10,

  },
  barfill: {
    height: 3,
    backgroundColor: "#62D4A1",
    width: 30,
    borderRadius: 4,
  },
  line:{
    height:2,
    backgroundColor:'#4E4B66',
    marginTop:10,
    marginBottom:20,
  },
  
});
