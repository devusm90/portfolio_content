import React from "react";
import { Image, StyleSheet, Text, View } from "react-native";

import Container from "@components/Container";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function Personalised({ navigation , route }: { navigation: any, route:any }) {
  const username = route.params.paramKey;
  console.log("username",username);
  setTimeout(() => {
    navigation.navigate('Home',{
      paramKey: username
    })        
}, 5000);  

  return (
    <Container>
      <View style={styles.middlealign}>
        <View>
          <Image
            style={styles.logo}
            source={require("@assets/images/tackl-icon.png")}
          />
        </View>

        <View style={styles.textwrap}>
          <Text style={styles.text}>Unboxing your</Text>
          <Text style={styles.text}>learning experience...</Text>
        </View>

        
      </View>
    </Container>
  );
}

const styles = StyleSheet.create({
  middlealign: {
    flex: 1,
    justifyContent: "center",
  },
  textwrap: {
    paddingTop: 20,
    paddingBottom: 20,
  },
  text: {
    color: "#FFF1E4",
    textAlign: "center",
    fontSize: 18,
    fontFamily: "PoppinsRegular",
  },
  logo: {
    width: 100,
    height: 100,
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 20,
  },
  btnText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "bold",
    paddingTop: 15,
  },
});
