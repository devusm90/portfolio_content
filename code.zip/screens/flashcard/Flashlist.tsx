import BottomNav from "@components/BottomNav";
import Container from "@components/Container";
import HeaderNav from "@components/HeaderNav";
import React from "react";
import {
  Dimensions,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View
} from "react-native";

import qbankData from "@data/flashlist.json";

const width = Dimensions.get("window").width; //full width

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function Flashlist({ navigation }: { navigation: any }) {
  const total = "12";
  const finished = "6";

  return (
    <Container>
      <HeaderNav />
      <View style={styles.tabs}>
        <Pressable
          style={styles.tabtn}
          onPress={() => navigation.navigate("Learn")}
        >
          <Text style={styles.btnText}>Q-Bank</Text>
        </Pressable>
        <Pressable
          style={styles.tabtnblue}
          onPress={() => navigation.navigate("Flashlist")}
        >
          <Text style={styles.btnwhite}>Flashcard</Text>
        </Pressable>
        <Pressable
          style={styles.tabtn}
          onPress={() => navigation.navigate("Tests")}
        >
          <Text style={styles.btnText}>Tests</Text>
        </Pressable>
      </View>
      <ScrollView>



        {qbankData.map((qbank, index) => (
          <View key={index}>
            <Text style={styles.lastatm}>{qbank.title}</Text>
            <ScrollView style={styles.horzwrap} horizontal={true}>
              {qbank.items.map((item, index) => (
                <Pressable
                  style={styles.qbank}
                  onPress={() =>
                    navigation.navigate("Flashsub", { value: item.id })
                  }
                  key={index}
                >
                  <Image
                    style={styles.rocket}
                    source={require("@assets/images/rocket.png")}
                  />
                  <Text style={styles.qtitle}>{item.title}</Text>
                  <Text style={styles.atmsts}>
                    {item.total} Cards
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        ))}
      </ScrollView>
      <BottomNav />
    </Container>
  );
}

const styles = StyleSheet.create({
  percentage: {
    position: "absolute",
    right: -10,
    top: -10,
    borderRadius: 50,
    width: 60,
    height: 60,
  },
  tabs: {
    flexDirection: "row",
    justifyContent: "space-between",
    backgroundColor: "#000",
    marginTop: 10,
    marginRight: 20,
    marginLeft: 20,
    padding: 2,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#4E4B66",
  },
  tabtn: {
    borderRadius: 6,
    padding: 10,
    margin: 2,
    flex: 1,
  },
  tabtnblue: {
    backgroundColor: "#777BD1",
    borderRadius: 6,
    padding: 10,
    margin: 2,
    flex: 1,
  },
  btnwhite: {
    color: "#fff",
    textAlign: "center",
    fontFamily: "PoppinsBold",
    fontSize: 14,
  },
  btnText: {
    color: "#777BD1",
    textAlign: "center",
    fontFamily: "PoppinsBold",
    fontSize: 14,
  },
  lastatm: {
    color: "#FFF1E4",
    marginLeft: 22,
    marginTop: 20,
    marginBottom: 10,
    fontFamily: "PoppinsSemiBold",
    fontSize: 14,
    opacity: 0.7,
  },
  col2: {
    backgroundColor: "#18191C",
    padding: 10,
    marginLeft: 20,
    marginRight: 20,
    flexDirection: "row",
    borderRadius: 10,
  },
  horzwrap: {
    paddingTop: 1,
    paddingLeft: 20,
  },
  qbank: {
    backgroundColor: "#31333B",
    padding: 16,
    borderRadius: 10,
    width: width / 2 - 24,
    marginLeft: 0,
    marginRight: 10,
    overflow: "hidden",
  },
  rocket: {
    width: 30,
    height: 33,
    marginTop: 10,
    marginBottom: 10,
  },
  atmsts: {
    color: "#FFF1E4",
    fontSize: 12,
    opacity: 0.7,
    fontFamily: "PoppinsRegular",
  },
  qtitle: {
    color: "#FFF1E4",
    fontFamily: "PoppinsSemiBold",
    fontSize: 18,
  },
});
