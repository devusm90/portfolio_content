import BottomNav from "@components/BottomNav";
import Container from "@components/Container";
import React from "react";
import {
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View
} from "react-native";

// import { useRoute } from "@react-navigation/native";

import qbankcat from "@data/flashsub.json";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function QbankMain({ navigation }: { navigation: any }) {
  // const route = useRoute();

  return (
    <Container>
      <View style={styles.hdrnavwrap}>
        <View style={styles.btmbtn}></View>
        <View style={styles.alglft}>
          <Pressable
            style={styles.btmbtn}
            onPress={() => navigation.navigate("Notification")}
          >
            <Image
              style={styles.notimg}
              source={require("@assets/images/notification.png")}
            />
          </Pressable>
          <Pressable
            style={styles.btmbtn}
            onPress={() => navigation.navigate("Search")}
          >
            <Image
              style={styles.srhimg}
              source={require("@assets/images/search.png")}
            />
          </Pressable>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.scrollview}>
        <Text style={styles.title}>{/* {route.params.value} */}</Text>
        <Text style={styles.subtitle}>20 Module</Text>
        <Image
          style={styles.yeloline}
          source={require("@assets/images/yellow-line.png")}
        />



        {qbankcat.map((qbank, index) => (
          <View style={styles.mainwrap} key={index}>
            {qbank.types.map((type, index) => (
              <View key={index}>
                <Text style={styles.catitle}>{type.title}</Text>
                {type.items.map((item, index) => (
                  <Pressable
                    style={styles.qitem}
                    key={index}
                    onPress={() =>
                      navigation.navigate("Flashcards", { value: item.id })
                    }
                  >
                    <View style={styles.grcontent}>
                      <Text style={styles.qtitle}>{item.title}</Text>
                      <Text style={styles.grsubtit}>{item.total} Cards</Text>
                      <Image
                        style={styles.forward}
                        source={require("@assets/images/forward.png")}
                      />
                    </View>
                  </Pressable>
                ))}
              </View>
            ))}
          </View>
        ))}
      </ScrollView>
      <BottomNav />
    </Container>
  );
}

const styles = StyleSheet.create({
  hdrnavwrap: {
    marginTop: 50,
    flexDirection: "row",
    justifyContent: "space-between",
    paddingLeft: 10,
    paddingRight: 10,
    paddingBottom: 10,
  },
  btmbtn: {
    paddingLeft: 10,
    paddingRight: 10,
  },
  btnText: {
    color: "#fff",
    fontSize: 14,
    fontFamily: "PoppinsRegular",
  },
  alglft: {
    flexDirection: "row",
  },
  userimg: {
    width: 36,
    height: 36,
    borderRadius: 30,
  },
  notimg: {
    width: 27,
    height: 24,
    marginTop: 6,
  },
  srhimg: {
    width: 24,
    height: 24,
    marginTop: 4,
  },
  title: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 27,
    textAlign: "center",
    marginTop: 20,
    marginBottom: 10,
  },
  scrollview: {},
  subtitle: {
    color: "#FFF1E4",
    opacity: 0.7,
    textAlign: "center",
    fontFamily: "PoppinsSemiBold",
    fontSize: 14,
  },
  yeloline: {
    width: 60,
    height: 4,
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 6,
  },
  col3: {
    margin: 10,
    flexDirection: "row",
    marginBottom: 0,
  },
  gritem: {
    backgroundColor: "#18191C",
    padding: 6,
    margin: 6,
    flex: 1,
    borderRadius: 10,
  },
  tagimg: {
    width: 26,
    height: 29,
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 6,
  },
  grtitle: {
    color: "#FFF1E4",
    textAlign: "center",
    marginTop: 6,
    fontFamily: "PoppinsRegular",
    fontSize: 12,
  },
  dumy: {
    color: "#f00",
    fontSize: 16,
  },
  mainwrap: {
    padding: 20,
    paddingTop: 0,
  },
  catitle: {
    color: "#FFF1E4",
    opacity: 0.7,
    fontFamily: "PoppinsSemiBold",
    fontSize: 14,
    marginTop: 20,
  },
  qitem: {
    backgroundColor: "#18191C",
    padding: 10,
    marginTop: 10,
    position: "relative",
    paddingRight: 40,
    flexDirection: "row",
    borderRadius: 12,
  },
  forward: {
    width: 10,
    height: 18,
    position: "absolute",
    top: 15,
    right: -20,
  },
  qtitle: {
    color: "#FFF1E4",
    fontFamily: "PoppinsSemiBold",
    fontSize: 14,
  },

  grcontent: {
    flex: 9,
    paddingLeft: 10,
  },
  grsubtit: {
    color: "#FFF1E4",
    opacity: 0.7,
    fontFamily: "PoppinsRegular",
    fontSize: 12,
    marginTop: 6,
  },
});
