import Container from "@components/Container";
import { useNavigation } from "@react-navigation/native";
import React, { useRef, useState } from "react";
import {
  Animated,
  Dimensions,
  Image, Pressable,
  StyleSheet,
  Text, View
} from "react-native";

import flashCard from "@data/flashcard.json";
import { ScrollView } from "react-native-gesture-handler";

import * as Progress from "react-native-progress";

const width = Dimensions.get("window").width; //full width




export default function Flashcards() {

  const [buttonEnable, setEnable] = useState(false);  

  const navigation = useNavigation();

  const animatedValue = new Animated.Value(0);
  const animatedValueRef = useRef(animatedValue);
  let currentValue = 0;

  animatedValueRef.current.addListener(({ value }) => {
    currentValue = value;
  });



  const goCongratulations = () => {
    navigation.navigate("Congratulations");
};


  const flipAnimation = () => {      
    if (currentValue >= 90) {      
      // console.log("if called");
      Animated.spring(animatedValueRef.current, {
        toValue: 0,
        tension: 10,
        friction: 8,
        useNativeDriver: false,
      }).start();
      setEnable(false);
    } else {
      
      // console.log("else called");
      Animated.spring(animatedValueRef.current, {       
        toValue: 180,
        tension: 10,
        friction: 8,
        useNativeDriver: false,
      }).start();
      setEnable(true);      
    }    
  }; 

  const frontInterpolate = animatedValueRef.current.interpolate({
    inputRange: [0, 180],
    outputRange: ["0deg", "180deg"],
  });

  const frontAnimatedStyle = {
    transform: [{ rotateY: frontInterpolate }],
  };

  const backInterpolate = animatedValueRef.current.interpolate({
    inputRange: [0, 180],
    outputRange: ["180deg", "360deg"],
  });

  const backAnimatedStyle = {
    transform: [{ rotateY: backInterpolate }],
  };

  //Move to next card
  const fullData = flashCard.length;
  const [currentIndex, setIndex] = useState(0);
  const [indexCounter, setCounter] = useState(1);
  const [progress, setProgress] = useState((1 / fullData));

  const showNextCard = () => {      
    console.log("currentIndex1..",currentIndex);
    const newIndex = currentIndex + 1; 
    if (newIndex < fullData) {   
      setIndex(newIndex);
      setCounter(indexCounter => indexCounter + 1);
      console.log("newIndex..",newIndex);
      Animated.spring(animatedValueRef.current, {
        toValue: 0,
        tension: 10,
        friction: 8,
        useNativeDriver: false,
      }).start();
      setEnable(false);

      if(progress < 1) {
        setProgress(progress + 1 / fullData);
        console.log("progress2..",progress);
      }  
    }else if(newIndex == fullData){
      console.log("else called");
      // setTimeout(() => {
        goCongratulations();
    // }, 5000);        
      
    }
  };
  
  return (
    <Container>
      <View style={styles.col3}>
        <Image
          style={styles.taclimg}
          source={require("@assets/images/tackl-icon.png")}
        />
        <View style={styles.inline}>
          <Text style={styles.count}>Question {indexCounter} of {fullData}</Text>
        </View>

        <View style={styles.inline}>
          <Pressable
            style={styles.tpimg}
            onPress={() => navigation.navigate("Learn")}
          >
            <Image
              style={styles.clse}
              source={require("@assets/images/close2.png")}
            />
          </Pressable>
        </View>
      </View>

      <View style={styles.greybar}>        
        <Progress.Bar progress={progress} width={width - 40} color="#62D4A1" borderWidth={0}/>
      </View>


      <ScrollView contentContainerStyle={styles.scrollview}>
        {/* {flashCard.map((flashcard, index) => (
          <View key={index}> */}

            <View style={styles.flashCard}>
            <Image
              style={styles.flashImage}
              source={require("@assets/images/flashcard.png")}
            />
              <Animated.View style={[styles.frontcard, frontAnimatedStyle]}>
                <Text style={styles.qusText}>
                  {flashCard[currentIndex].question}
                </Text>
                  <Image
                    style={styles.leftImg}
                    source={require("@assets/images/flashcard_left_img.png")}
                  />
                  <Image
                    style={styles.rightImg}
                    source={require("@assets/images/tag_img.png")}
                  /> 
                <Image
                  style={styles.btmImg}
                  source={require("@assets/images/flashcard_right_img.png")}
                />
              </Animated.View>

              <Animated.View style={[styles.backcard, backAnimatedStyle]}>
                <Text style={styles.anslabel}>Answer</Text>
                <Text style={styles.ansText}>{flashCard[currentIndex].answer}</Text>
                <Text style={styles.guss}>Did you guess right?</Text>

                <Image
                  style={styles.leftImg}
                  source={require("@assets/images/flashcard_right_img.png")}
                />
                <Image
                    style={styles.rightImg}
                    source={require("@assets/images/tag_img.png")}
                  /> 
                <Image
                  style={styles.btmImg}
                  source={require("@assets/images/flashcard_right_flip.png")}
                />
              </Animated.View>
            </View>

            <Animated.View style={[frontAnimatedStyle]}>
              <Pressable style={styles.rollbtn} onPress={flipAnimation}>
                <Image
                  style={styles.rollimg}
                  source={require("@assets/images/Refresh.png")}
                />
              </Pressable>
            </Animated.View>
          {/* </View>
        ))} */}
      </ScrollView>

      <View style={styles.btnWrap}>
        <Pressable style={buttonEnable ? styles.nehBtn : styles.nehBtnInactive} onPress={showNextCard}>
          <Image
            style={styles.noImg}
            source={require("@assets/images/close_circle.png")}
          />
          <Text style={styles.btnText}>Neh!</Text>
        </Pressable>
        <Pressable style={buttonEnable ? styles.gotBtn : styles.gotBtnIncative} onPress={showNextCard}>
          <Image
            style={styles.yesImg}
            source={require("@assets/images/tick_circle.png")}
          />
          <Text style={styles.btnText}>Got It!</Text>
        </Pressable>
      </View>
    </Container>
  );
}

const styles = StyleSheet.create({ 
  col3: {
    paddingTop: 60,
    paddingBottom: 10,
    flexDirection: "row",
    paddingLeft: 10,
    paddingRight: 10,
    justifyContent: "space-between",
    marginBottom: 10,
  },
  inline: {
    flexDirection: "row",
  },
  taclimg: {
    width: 30,
    height: 30,
  },
  bkmark: {
    width: 20,
    height: 24,
  },
  clse: {
    width: 20,
    height: 20,
    position: "relative",
    top: 3,
  },
  tpimg: {
    paddingLeft: 10,
    paddingRight: 10,
  },
  count: {
    fontFamily: "RobotoBold",
    color: "#FFF1E4",
    fontSize: 14,
    paddingTop: 4,
  },

  greybar: {
    width: width - 40,
    backgroundColor: "#4E4B66",
    marginLeft: 20,
    borderRadius: 4,
    marginBottom: 30,
  },
  barfill: {
    height: 3,
    backgroundColor: "#62D4A1",
    width: 100,
    borderRadius: 4,
  },

  scrollview: {
    padding: 20,
  },
  flashImage:{
    width:287,
    height:420,
    position:"absolute",
    left:30,
    top:16
  },
  flashCard: {

    width: 288,
  },

  frontcard: {
    width: 288,
    height: 450,
    padding: 40,
    textAlign: "center",
    backgroundColor: "#18191C",
    backfaceVisibility: "hidden",
    position: "relative",
    borderColor: "#ED813F",
    borderWidth: 1,
    borderRadius: 30,
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    marginRight:30
  },
  backcard: {
    width: 288,
    height: 450,
    padding: 40,
    textAlign: "center",
    backgroundColor: "#18191C",
    borderColor: "#62D4A1",
    borderWidth: 1,
    borderRadius: 30,
    position: "absolute",
    left: 0,
    top: 0,
    backfaceVisibility: "hidden",
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  qusText: {
    fontFamily: "PoppinsSemiBold",
    fontSize: 20,
    color: "#ffffff",
    textAlign: "center",
  },
  anslabel: {
    fontFamily: "PoppinsSemiBold",
    fontSize: 16,
    color: "#62D4A1",
    textAlign: "center",
  },
  ansText: {
    fontFamily: "PoppinsSemiBold",
    fontSize: 24,
    color: "#ffffff",
    textAlign: "center",
  },
  guss: {
    fontFamily: "PoppinsSemiBold",
    fontSize: 12,
    color: "#FFF1E4",
    textAlign: "center",
    position: "absolute",
    bottom: 60,
    opacity: 0.7,
  },
  rollbtn: {    
    marginLeft:"auto",
    marginRight:"auto"
  },
  rollimg: {
    width: 76,
    height: 76,
    marginTop:-40
  },
  btnText: {
    color: "#000000",
    fontFamily: "PoppinsSemiBold",
    fontSize: 15,
    letterSpacing:1,
    marginTop:4
  },
  btnWrap: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 10,
    paddingRight: 40,
    paddingLeft: 40,
  },
  nehBtn: {
    backgroundColor: "#FF968F",
    borderRadius: 12,
    width: 120,
    height: 56,
    textAlign: "center",
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 20,
    opacity: 1,
  },
  nehBtnInactive:{
    backgroundColor: "#FF968F",
    borderRadius: 12,
    width: 120,
    height: 56,
    textAlign: "center",
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 20,
    opacity: 0.4,
  },
  noImg: {
    width: 20,
    height: 20,
    marginRight:13
  },
  gotBtn: {
    backgroundColor: "#62D4A1",
    borderRadius: 12,
    width: 120,
    height: 56,
    textAlign: "center",
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    opacity: 1,
  },
  gotBtnIncative:{
    backgroundColor: "#62D4A1",
    borderRadius: 12,
    width: 120,
    height: 56,
    textAlign: "center",
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    opacity: 0.4,
  },
  yesImg: {
    width: 20,
    height: 20,
    marginRight:13
  },
  rightImg:{
    width: 20,
    height: 23,
    position:"absolute",
    right:22,
    top:16
  },
  leftImg: {
    width: 53,
    height: 46,
    opacity: 0.4,
    position: "absolute",
    top: 20,
    left: 20,
  },
  btmImg: {
    width: 53,
    height: 46,
    opacity: 0.4,
    position: "absolute",
    bottom: 20,
    right: 20,
  },
});
