import Container from "@components/Container";
import React from "react";
import { Pressable, ScrollView, StyleSheet, Text } from "react-native";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function QuizExplore({ navigation }: { navigation: any }) {
  const quizrule = () => {
    navigation.navigate("QuizRules");
  };

  return (
    <Container>
      <ScrollView>
        <Text style={styles.title}>Explore Quizzes</Text>
      </ScrollView>

      <Pressable style={styles.btn} onPress={quizrule}>
        <Text style={styles.btnText}>Join</Text>
      </Pressable>
    </Container>
  );
}

const styles = StyleSheet.create({
  title: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 27,
    textAlign: "center",
    marginTop: 120,
    marginBottom: 10,
  },
  btn: {
    backgroundColor: "#787bd1",
    marginTop: 30,
    height: 50,
    borderRadius: 12,
    width: 280,
    textAlign: "center",
    marginLeft: "auto",
    marginRight: "auto",
    marginBottom: 20,
  },
  btnText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "bold",
    paddingTop: 15,
  },
});
