import BottomNav from "@components/BottomNav";
import Container from "@components/Container";
import React from "react";
import {
  Dimensions,
  Image,
  Linking,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

const width = Dimensions.get("window").width; //full width

// eslint-disable-next-line no-unused-vars, @typescript-eslint/no-unused-vars, @typescript-eslint/no-explicit-any
export default function Profile({ navigation }: { navigation: any }) {
  return (
    <Container>
      <ScrollView contentContainerStyle={styles.scrollview}>
        <View style={styles.container}>
          <View style={styles.imageCenter}>
            <Pressable onPress={() => navigation.navigate("ProfileAll")}>
              <Image
                style={styles.userImage}
                source={require("@assets/images/user_img.png")}
              />
            </Pressable>
          </View>
          <Text style={styles.userName}>Profile</Text>
          <Text style={styles.place}>JEE</Text>
          <View style={styles.imageCenter}>
            <Image
              style={styles.lineImage}
              source={require("@assets/images/line_img.png")}
            />
          </View>

          <View style={styles.catdOuter}>
            <Image
              style={styles.rollImage}
              source={require("@assets/images/roll.png")}
            />
            <Text style={styles.progressCard}>Progress Card</Text>
          </View>

          <View style={styles.cardOuter}>
            <View style={styles.singleCard}>
              <Image
                style={styles.shapeImage}
                source={require("@assets/images/bookmark_small.png")}
              />
              <Text style={styles.cardTitle}>Bookmarks</Text>
            </View>
            <View style={styles.singleCard}>
              <Image
                style={styles.shapeImage}
                source={require("@assets/images/eraser_small.png")}
              />
              <Text style={styles.cardTitle}>Correction</Text>
            </View>
          </View>
          <View style={styles.cardOuter}>
            <View style={styles.singleCard}>
              <Image
                style={styles.shapeImage}
                source={require("@assets/images/gift_small.png")}
              />
              <Text style={styles.cardTitle}>Rewards</Text>
            </View>
            <View style={styles.singleCard}>
              <Image
                style={styles.shapeImage}
                source={require("@assets/images/question.png")}
              />
              <Text style={styles.cardTitle}>Doubts</Text>
            </View>
          </View>
          <View>
            <View style={styles.linkOuter}>
              <Text
                style={styles.linkName}
                onPress={() => Linking.openURL("http://google.com")}
              >
                Subscription Plans
              </Text>
              <Image
                style={styles.arrowImage}
                source={require("@assets/images/right_arrow.png")}
              />
            </View>
            <View style={styles.linkOuter}>
              <Text
                style={styles.linkName}
                onPress={() => Linking.openURL("http://google.com")}
              >
                Help & Feedback
              </Text>
              <Image
                style={styles.arrowImage}
                source={require("@assets/images/right_arrow.png")}
              />
            </View>
            <View style={styles.linkOuter}>
              <Text
                style={styles.linkName}
                onPress={() => Linking.openURL("http://google.com")}
              >
                FAQ
              </Text>
              <Image
                style={styles.arrowImage}
                source={require("@assets/images/right_arrow.png")}
              />
            </View>
          </View>
          <View style={styles.catdOuter}>
            <Image
              style={styles.rollImage}
              source={require("@assets/images/share_icon.png")}
            />
            <Text style={styles.progressCard}>Share App</Text>
          </View>
        </View>
      </ScrollView>

      <BottomNav />
    </Container>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0b0b13",
    paddingLeft: 20,
    paddingRight: 20,
    paddingTop: 60,
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
  },
  scrollview: {},
  userImage: {
    width: 80,
    height: 80,
    borderRadius: 100,
    marginBottom: 20,
  },
  userName: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 24,
    textAlign: "center",
    marginBottom: 3,
  },
  place: {
    fontFamily: "RobotoRegular",
    color: "#A0A3BD",
    fontSize: 12,
    textAlign: "center",
    marginBottom: 10,
  },
  lineImage: {
    width: 99,
    height: 7,
  },
  imageCenter: {
    textAlign: "center",
    display: "flex",
    justifyContent: "center",
    flexDirection: "row",
    width: "100%",
  },
  progressCard: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 20,
    textAlign: "center",
    marginBottom: 10,
    marginLeft: 20,
  },
  catdOuter: {
    backgroundColor: "#18191C",
    borderRadius: 16,
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "flex-start",
    marginTop: 30,
    height: 120,
    paddingRight: 30,
    marginBottom: 25,
    overflow: "hidden",
  },
  rollImage: {
    width: 120,
    height: 120,
    marginLeft: -15,
    marginTop: -22,
  },
  shapeImage: {
    width: 150,
    height: 150,
    position: "absolute",
    left: -15,
    top: -5,
  },
  cardOuter: {
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 30,
  },
  cardTitle: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 16,
    textAlign: "center",
    marginTop: 125,
    marginLeft: -30,
  },
  singleCard: {
    backgroundColor: "#18191C",
    borderRadius: 16,
    width: width / 2 - 30,
    height: 160,
    marginBottom: 30,
    overflow: "hidden",
    position: "relative",
  },
  linkName: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 16,
    marginBottom: 18,
  },
  arrowImage: {
    width: 6,
    height: 13,
  },
  linkOuter: {
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
  },
});
