import BottomNav from "@components/BottomNav";
import Container from "@components/Container";
import React from "react";
import { Image, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

// eslint-disable-next-line no-unused-vars, @typescript-eslint/no-unused-vars, @typescript-eslint/no-explicit-any
export default function Search({ navigation }: { navigation: any }) {
  return (
    <Container>
      <View style={styles.searchwrap}>

      <SafeAreaView style={styles.safesear}>
        <Image style={styles.searchimg} source={require("@assets/images/search-bg.png")}/>
        <TextInput
          style={styles.input}
          placeholder="Search"
          placeholderTextColor="#6E7191"
        />
    </SafeAreaView>



      </View>


      <ScrollView contentContainerStyle={styles.scrollview}>
        <Text style={styles.title}>Recent Search</Text>
      </ScrollView>
      <BottomNav />
    </Container>
  );
}

const styles = StyleSheet.create({
  scrollview:{
    padding:20,
    paddingTop:10,
  },
  searchwrap:{
    marginTop:80,
    padding:20,

  },
  title: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 22,
    marginBottom: 10,
  },
  safesear:{
    position:'relative',
  },
  searchimg:{
    width:20,
    height:20,
    position:'absolute',
    zIndex:9,
    top:15,
    left:12,
  },

  input: {
    borderColor: "#6E7191",
    borderWidth: 1,
    backgroundColor: "#0B0B13",
    color: "#fff",
    height: 50,
    fontSize: 16,
    borderRadius: 10,
    paddingLeft: 45,
  },






});
