import Container from "@components/Container";
import React from "react";
import { StyleSheet, Text } from "react-native";

// eslint-disable-next-line no-unused-vars, @typescript-eslint/no-unused-vars, @typescript-eslint/no-explicit-any
export default function Congratulations({ navigation }: { navigation: any }) {
  return (
    <Container>
      <Text style={styles.title}>Congratulations</Text>
    </Container>
  );
}

const styles = StyleSheet.create({
  title: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 27,
    textAlign: "center",
    marginTop: 120,
    marginBottom: 10,
  },
});
