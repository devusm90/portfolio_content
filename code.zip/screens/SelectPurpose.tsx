import { BASE_URL } from "@env";
import AsyncStorage from '@react-native-async-storage/async-storage';
import React from "react";
import {
  Image,
  ImageBackground,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View
} from "react-native";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function SelectPurpose({ navigation }: { navigation: any }) {

const purposeChoose = async (purposeType: string) => {
  try {
    const jsonValue = await AsyncStorage.getItem('UserInfo') as string
    const parsed = JSON.parse(jsonValue);

    const onboardingInfo = {      
        purpose: purposeType,
        fullName: " ",
        branch: " ",
        course: {         
        }      
    };   

    //Save data in local storage
    await AsyncStorage.setItem('OnboardingInfo', JSON.stringify(onboardingInfo));
    console.log("OnboardingInfo purpose",onboardingInfo);

    //Save purpose in DB
    const postData = JSON.stringify({
      "purpose": purposeType,
      "fullName": " ",
      "branch": " ",
      "course": {         
      }      
    });

    const response = await fetch(`${BASE_URL}/onboard/OnboardingData`, {
      method: "POST",
      headers: {
        'Authorization': 'Bearer ' +parsed.IdToken,  
        'Accept': 'application/json',
        'Content-Type': 'application/json'  
      },
      body: postData
     
    });

    const saveDataJson = await response.json();
    navigation.navigate("YourName")
    console.log("saveDataJson",saveDataJson);
    return saveDataJson.success; 
  } catch (error) {
      console.error(error);
      return false;
  }
}


// const getData = async () => {    
//   try {
//     const jsonValue = await AsyncStorage.getItem('UserInfo') as string
//     const parsed = JSON.parse(jsonValue);
//     const savedresponse = await fetch(`${BASE_URL}/onboard/OnboardingData`, {
//       method: "GET",
//       headers: {
//         'Authorization': 'Bearer ' +parsed.IdToken,  
//         'Accept': 'application/json',
//         'Content-Type': 'application/json'  
//       }
//     });

//     const savedDataJson = await savedresponse.json();
//     console.log("savedDataJson",savedDataJson);

//     if(savedDataJson){
//       const fieldvalue = savedDataJson.data.username;      
//       console.log("fieldvalue branch",fieldvalue);   }

//     return savedDataJson.success;   

//   } catch (error) {
//     console.error(error);
//     return false;
//   }
// }




  return (
    <View style={styles.container}>
      <ImageBackground
        source={require("@assets/images/main-bg-full.png")}
        style={styles.bgimage}
      ></ImageBackground>

      <ScrollView contentContainerStyle={styles.scrollview}>
        <Text style={styles.title}>I’m here for</Text>
        <Image
          style={styles.yeloline}
          source={require("@assets/images/yellow-line.png")}
        />

        <SafeAreaView style={styles.content}>
          <Pressable onPress={() =>{
              purposeChoose('Exam')             
          }}>
            <Image
              style={styles.bookimg}
              source={require("@assets/images/book.png")}
            />
            <Text style={styles.subtitle}>Exam preparation</Text>
            <Text style={styles.whitetext}>
              Let us help you to learn more efficiently
            </Text>
          </Pressable>
        </SafeAreaView>
        <SafeAreaView style={styles.content}>
          <Pressable onPress={() => {
             purposeChoose('Quiz')  
          }}>
            <Image
              style={styles.quizimg}
              source={require("@assets/images/quiz.png")}
            />
            <Text style={styles.subtitle}>Quiz</Text>
            <Text style={styles.whitetext}>
              Let us help you to learn more efficiently
            </Text>
          </Pressable>
        </SafeAreaView>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0b0b13",
  },
  bgimage: {
    flex: 1,
    position: "absolute",
    width: "100%",
    height: "100%",
  },
  title: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 27,
    textAlign: "center",
    marginTop: 120,
    marginBottom: 10,
  },
  yeloline: {
    width: 60,
    height: 4,
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 6,
    marginBottom: 20,
  },
  content: {
    alignSelf: "stretch",
    padding: 20,
    backgroundColor: "#18191C",
    margin: 20,
    marginBottom: 0,
    borderRadius: 16,
  },
  bookimg: {
    width: 150,
    height: 150,
    marginLeft: "auto",
    marginRight: "auto",
  },
  quizimg: {
    width: 120,
    height: 120,
    marginLeft: "auto",
    marginRight: "auto",
    marginBottom: 10,
  },
  subtitle: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 20,
    textAlign: "center",
    marginBottom: 10,
  },
  whitetext: {
    fontSize: 14,
    color: "#FFF1E4",
    textAlign: "center",
    fontFamily: "PoppinsRegular",
  },
  scrollview: {},
});
