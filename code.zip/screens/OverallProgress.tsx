/* eslint-disable react/jsx-no-undef */
import Container from "@components/Container";
import React from "react";
import { Dimensions, Image, StyleSheet, Text, View } from "react-native";
import { LineChart } from "react-native-chart-kit";

const screenWidth = Dimensions.get("window").width;

export const data = {
  labels: [],
  datasets: [
    {
      data: [
        Math.random() * 100,
        Math.random() * 100,
        Math.random() * 100,
        Math.random() * 100,
        Math.random() * 100,
        Math.random() * 100,
      ],
      color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`, // optional
      strokeWidth: 3, // optional
    },
  ],
};

// eslint-disable-next-line no-unused-vars, @typescript-eslint/no-unused-vars, @typescript-eslint/no-explicit-any
export default function OverallProgress({ navigation }: { navigation: any }) {
  return (
    <Container>
      <View style={styles.container}>
        <View style={styles.top}>
          <View style={styles.smilyBox}>
            <Image
              style={styles.smilyImg}
              source={require("@assets/images/star_smiley.png")}
            />
            <Text style={styles.graphHead}>You are doing greattt!</Text>
          </View>

          <LineChart
            data={data}
            width={screenWidth} // from react-native
            height={520}
            yAxisLabel=""
            fromZero
            yAxisSuffix=""
            yAxisInterval={1} // optional, defaults to 1
            chartConfig={{
              backgroundColor: "red",
              backgroundGradientFrom: "transparent",
              backgroundGradientTo: "transparent",
              decimalPlaces: 2, // optional, defaults to 2dp
              color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
              style: {
                borderRadius: 0,
                marginLeft: 15,
              },
              propsForDots: {
                r: "4",
                strokeWidth: "1",
                stroke: "transparent",
              },
            }}
            bezier
            style={{
              marginVertical: 8,
              borderRadius: 16,
            }}
          />
        </View>
      </View>
    </Container>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "column",
  },
  top: {
    flex: 1.8,
    marginTop: 150,
  },
  smilyImg: {
    width: 63,
    height: 63,
  },
  smilyBox: {
    paddingLeft: 30,
    paddingTop: 10,
    paddingBottom: 10,
    marginTop: 0,
    disply: "flex",
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#18191C",
    borderRadius: 12,
    marginLeft: 15,
    marginRight: 15,
    marginBottom: 70,
  },
  graphHead: {
    color: "#fffff",
    paddingLeft: 30,
    fontSize: 14,
    fontFamily: "PoppinsBold",
    lineHeight: 21,
  },
});
