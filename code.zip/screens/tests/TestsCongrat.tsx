import Container from "@components/Container";
import React from "react";
import { Image, StyleSheet, Text, View } from "react-native";

// eslint-disable-next-line no-unused-vars, @typescript-eslint/no-explicit-any, @typescript-eslint/no-unused-vars
export default function TestsCongrat({ navigation }: { navigation: any }) {
  // const testcongrat = () => {
  //   navigation.navigate("TestsCongrat");
  // };

  return (
    <Container>
      <View style={styles.maincontainer}>
        <Image
          style={styles.congimg}
          source={require("@assets/images/congrats.png")}
        />
        <Text style={styles.title}>Congratulations 👏🏻</Text>
        <Image
          style={styles.yeloline}
          source={require("@assets/images/yellow-line.png")}
        />
        <Text style={styles.congtext}>That was quite a fiest</Text>
      </View>
    </Container>
  );
}

const styles = StyleSheet.create({
  maincontainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  congimg: {
    width: 240,
    height: 181,
  },
  yeloline: {
    width: 60,
    height: 4,
    marginTop: 6,
  },
  title: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 27,
    textAlign: "center",
    marginBottom: 10,
  },
  congtext: {
    fontFamily: "PoppinsRegular",
    color: "#FFF1E4",
    fontSize: 18,
    textAlign: "center",
    marginTop: 30,
  },
});
