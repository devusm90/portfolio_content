import Container from "@components/Container";
import React from "react";
import {
  Dimensions,
  Image,
  ImageBackground,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

const width = Dimensions.get("window").width; //full width

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function TestSubmit({ navigation }: { navigation: any }) {
  const testcongrat = () => {
    navigation.navigate("TestsCongrat");
  };

  return (
    <Container>
      <View style={styles.col3}>
        <Image
          style={styles.taclimg}
          source={require("@assets/images/tackl-icon.png")}
        />

        <View style={styles.inline}>
          <Pressable
            style={styles.tpimg}
            onPress={() => navigation.navigate("SolveMcq")}
          >
            <Image
              style={styles.clse}
              source={require("@assets/images/close2.png")}
            />
          </Pressable>
        </View>
      </View>

      <View style={styles.greybar}>
        <View style={styles.barfill}></View>
      </View>

      <ScrollView>
        <View style={styles.greybox}>
          <Text style={styles.title}>Questions</Text>
          <Image
            style={styles.yeloline}
            source={require("@assets/images/yellow-line.png")}
          />

          <View style={styles.revwrap}>
            <ImageBackground
              source={require("@assets/images/answered.png")}
              style={styles.circle}
            >
              <Text style={styles.wtext}>1</Text>
            </ImageBackground>
            <ImageBackground
              source={require("@assets/images/forreview.png")}
              style={styles.circle}
            >
              <Text style={styles.wtext}>2</Text>
            </ImageBackground>
            <ImageBackground
              source={require("@assets/images/unanswered.png")}
              style={styles.circle}
            >
              <Text style={styles.wtext}>3</Text>
            </ImageBackground>
            <ImageBackground
              source={require("@assets/images/answered.png")}
              style={styles.circle}
            >
              <Text style={styles.wtext}>4</Text>
            </ImageBackground>
            <ImageBackground
              source={require("@assets/images/unanswered.png")}
              style={styles.circle}
            >
              <Text style={styles.wtext}>5</Text>
            </ImageBackground>
            <ImageBackground
              source={require("@assets/images/answered.png")}
              style={styles.circle}
            >
              <Text style={styles.wtext}>6</Text>
            </ImageBackground>
            <ImageBackground
              source={require("@assets/images/forreview.png")}
              style={styles.circle}
            >
              <Text style={styles.wtext}>7</Text>
            </ImageBackground>
            <ImageBackground
              source={require("@assets/images/answered.png")}
              style={styles.circle}
            >
              <Text style={styles.wtext}>8</Text>
            </ImageBackground>
            <ImageBackground
              source={require("@assets/images/answered.png")}
              style={styles.circle}
            >
              <Text style={styles.wtext}>9</Text>
            </ImageBackground>
            <ImageBackground
              source={require("@assets/images/answered.png")}
              style={styles.circle}
            >
              <Text style={styles.wtext}>10</Text>
            </ImageBackground>
            <ImageBackground
              source={require("@assets/images/unanswered.png")}
              style={styles.circle}
            >
              <Text style={styles.wtext}>11</Text>
            </ImageBackground>
            <ImageBackground
              source={require("@assets/images/unanswered.png")}
              style={styles.circle}
            >
              <Text style={styles.wtext}>12</Text>
            </ImageBackground>
          </View>
        </View>

        <View style={styles.infowrap}>
          <View style={styles.inline}>
            <View style={styles.grencir}></View>
            <Text style={styles.cirtitle}>Answered</Text>
          </View>
          <View style={styles.inline}>
            <View style={styles.redcir}></View>
            <Text style={styles.cirtitle}>For review</Text>
          </View>
          <View style={styles.inline}>
            <View style={styles.greycir}></View>
            <Text style={styles.cirtitle}>Un Answered</Text>
          </View>
        </View>
      </ScrollView>

      <View style={styles.btnwrap}>
        <Pressable style={styles.btn} onPress={testcongrat}>
          <Text style={styles.btnText}>Submit Test</Text>
        </Pressable>

        <Pressable style={styles.btnfill} onPress={testcongrat}>
          <Text style={styles.btnText}>Resumme</Text>
        </Pressable>
      </View>
    </Container>
  );
}

const styles = StyleSheet.create({
  col3: {
    paddingTop: 60,
    paddingBottom: 10,
    flexDirection: "row",
    paddingLeft: 10,
    paddingRight: 10,
    marginBottom: 4,
    justifyContent: "space-between",
  },
  inline: {
    flexDirection: "row",
  },
  taclimg: {
    width: 30,
    height: 30,
  },
  clse: {
    width: 20,
    height: 20,
    position: "relative",
    top: 3,
    right: 10,
  },
  greybar: {
    width: width - 40,
    backgroundColor: "#4E4B66",
    marginLeft: 20,
    borderRadius: 4,
  },
  barfill: {
    height: 3,
    backgroundColor: "#62D4A1",
    width: 100,
    borderRadius: 4,
  },
  greybox: {
    backgroundColor: "#18191C",
    margin: 20,
    marginBottom: 0,
    borderRadius: 16,
    padding: 20,
  },
  title: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 27,
    textAlign: "center",
    marginBottom: 10,
  },
  yeloline: {
    width: 60,
    height: 4,
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 6,
    marginBottom: 20,
  },
  infowrap: {
    margin: 26,
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 10,
  },
  grencir: {
    width: 14,
    height: 14,
    borderRadius: 16,
    marginRight: 4,
    borderWidth: 2,
    borderColor: "#62D4A1",
    marginTop: 3,
  },
  redcir: {
    width: 14,
    height: 14,
    borderRadius: 16,
    marginRight: 4,
    borderWidth: 2,
    borderColor: "#FD6150",
    marginTop: 3,
  },
  greycir: {
    width: 14,
    height: 14,
    borderRadius: 16,
    marginRight: 4,
    borderWidth: 2,
    borderColor: "#4E4B66",
    marginTop: 3,
  },
  cirtitle: {
    color: "#6E7191",
  },
  revwrap: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-evenly",
    alignContent: "flex-start",
    marginTop: 10,
  },
  circle: {
    width: 55,
    height: 55,
    margin: 6,
    borderRadius: 60,
    marginBottom: 12,
  },
  not: {
    width: 55,
    height: 55,
    margin: 6,
    borderWidth: 2,
    borderColor: "#6E7191",
    borderRadius: 60,
  },
  wtext: {
    textAlign: "center",
    fontSize: 18,
    fontFamily: "RobotoMedium",
    color: "#FFF1E4",
    marginTop: 16,
  },
  notext: {
    textAlign: "center",
    fontSize: 18,
    fontFamily: "RobotoMedium",
    color: "#6E7191",
    marginTop: 12,
  },
  btnwrap: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 10,
    paddingRight: 20,
    paddingLeft: 20,
  },
  btn: {
    height: 50,
    borderRadius: 12,
    width: width / 2 - 30,
    borderWidth: 2,
    borderColor: "#787bd1",
    textAlign: "center",
  },
  btnfill: {
    backgroundColor: "#787bd1",
    height: 50,
    borderRadius: 12,
    width: width / 2 - 30,
    textAlign: "center",
  },
  btnText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "bold",
    paddingTop: 12,
  },
});
