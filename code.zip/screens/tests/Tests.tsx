import BottomNav from "@components/BottomNav";
import Container from "@components/Container";
import HeaderNav from "@components/HeaderNav";
import React from "react";
import {
  Dimensions,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View
} from "react-native";

import tktest from "@data/tests.json";
const width = Dimensions.get("window").width; //full width

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function Tests({ navigation }: { navigation: any }) {
  return (
    <Container>
      <HeaderNav />
      <View style={styles.tabs}>
        <Pressable
          style={styles.tabtn}
          onPress={() => navigation.navigate("Learn")}
        >
          <Text style={styles.btnText}>Q-Bank</Text>
        </Pressable>
        <Pressable
          style={styles.tabtn}
          onPress={() => navigation.navigate("Flashlist")}
        >
          <Text style={styles.btnText}>Flashcard</Text>
        </Pressable>
        <Pressable
          style={styles.tabtnblue}
          onPress={() => navigation.navigate("Tests")}
        >
          <Text style={styles.btnwhite}>Tests</Text>
        </Pressable>
      </View>
      <ScrollView>
        <Text style={styles.lastatm}>Last Attempt</Text>
        <View style={styles.col2}>
          <View style={styles.s4}>
            <Image
              style={styles.graph}
              source={require("@assets/images/graph_img.png")}
            />
          </View>
          <View style={styles.s8}>
            <Text style={styles.atmhead}>Evaluvate your growth</Text>
            <Pressable onPress={() => navigation.navigate("OverallProgress")}>
              <Text style={styles.conlear}>
                See overall progress{" "}
                <Image
                  style={styles.rightblue}
                  source={require("@assets/images/right-blue.png")}
                />
              </Text>
            </Pressable>
          </View>
        </View>

        {tktest.map((qbank, index) => (
          <View key={index}>
            <Text style={styles.lastatm}>{qbank.title}</Text>
            <ScrollView style={styles.horzwrap} horizontal={true}>
              {qbank.items.map((item, index) => (
                <Pressable
                  style={styles.qbank}
                  onPress={() => navigation.navigate("TestSubTopic")}
                  key={index}
                >
                  <Image
                    style={styles.testimg}
                    source={require("@assets/images/test_doc.png")}
                  />
                  <Text style={styles.qtitle}>{item.title}</Text>
                  <Text style={styles.subtit}>{item.questions} Questions</Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        ))}
      </ScrollView>
      <BottomNav />
    </Container>
  );
}

const styles = StyleSheet.create({
  tabs: {
    flexDirection: "row",
    justifyContent: "space-between",
    backgroundColor: "#000",
    marginTop: 10,
    marginRight: 20,
    marginLeft: 20,
    padding: 2,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#4E4B66",
  },
  tabtn: {
    borderRadius: 6,
    padding: 10,
    margin: 2,
    flex: 1,
  },
  tabtnblue: {
    backgroundColor: "#777BD1",
    borderRadius: 6,
    padding: 10,
    margin: 2,
    flex: 1,
  },
  btnwhite: {
    color: "#fff",
    textAlign: "center",
    fontFamily: "PoppinsBold",
    fontSize: 14,
  },
  btnText: {
    color: "#777BD1",
    textAlign: "center",
    fontFamily: "PoppinsBold",
    fontSize: 14,
  },
  lastatm: {
    color: "#FFF1E4",
    marginLeft: 22,
    marginTop: 20,
    marginBottom: 10,
    fontFamily: "PoppinsSemiBold",
    fontSize: 14,
    opacity: 0.7,
  },
  col2: {
    backgroundColor: "#18191C",
    padding: 10,
    marginLeft: 20,
    marginRight: 20,
    flexDirection: "row",
    borderRadius: 10,
  },
  s4: {
    marginTop: 0,
    flex: 1,
  },
  graph: {
    width: 100,
    height: 95,
  },
  s8: {
    paddingLeft: 10,
    marginTop: 0,
    flex: 2,
  },
  atmhead: {
    color: "#FFF1E4",
    fontSize: 16,
    fontFamily: "PoppinsBold",
    marginTop: 20,
  },
  conlear: {
    color: "#777BD1",
    fontSize: 12,
    fontFamily: "PoppinsRegular",
    marginTop: 10,
  },
  rightblue: {
    width: 16,
    height: 16,
    paddingLeft: 10,
  },
  horzwrap: {
    paddingTop: 1,
  },
  qbank: {
    backgroundColor: "#31333B",
    padding: 16,
    borderRadius: 10,
    width: width / 2 - 24,
    marginLeft: 10,
    marginRight: 0,
  },
  testimg: {
    width: 50,
    height: 53,
    marginTop: 10,
    marginLeft: "auto",
    marginRight: "auto",
    marginBottom: 10,
  },
  qtitle: {
    color: "#FFF1E4",
    fontFamily: "PoppinsSemiBold",
    fontSize: 18,
    textAlign: "center",
  },
  subtit: {
    color: "#FFF1E4",
    textAlign: "center",
    fontFamily: "PoppinsRegular",
    opacity: 0.7,
  },
});
