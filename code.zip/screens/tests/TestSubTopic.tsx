import Container from "@components/Container";
import React, { useEffect, useState } from "react";
import {
  Image,
  Pressable,
  ScrollView,
  StyleSheet, Switch, Text,
  View
} from "react-native";

import mcqdata from "@data/testsubtopic.json";
// import ToggleSwitch from 'toggle-switch-react-native';

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function TestSubTopic({ navigation }: { navigation: any }) {

  //Switch
  const [isEnabled, setIsEnabled] = useState(false);
  const toggleSwitch = () => setIsEnabled(previousState => !previousState);

  //Slide Toggle
  const [ isOpen, setIsOpen ] = useState(false);

  useEffect(() => {
    console.log("open is: ", isOpen);
  }, [isOpen]);

  const slideToggle = () => {
    setIsOpen(!isOpen);
  };

 
 
  const gotoquestion = () => {
    navigation.navigate("QuestionMcq");
  };

  return (
    <Container>
      <ScrollView contentContainerStyle={styles.scrollview}>
        {mcqdata.map((mcq, index) => (
          <View key={index}>
            <Text style={styles.subtitle}>{mcq.subtitle}</Text>
            <Text style={styles.title}>{mcq.title}</Text>
            <Image
              style={styles.yeloline}
              source={require("@assets/images/yellow-line.png")}
            />
           

            <View style={styles.mcontent}>
              <View style={styles.lessdp}>
                  <Pressable onPress={slideToggle} style={styles.clickOuter}>              
                    <Text style={styles.lestitle}>
                      Lessons
                      <Text style={styles.lesoncount}>({mcq.lessons.length})</Text>
                    </Text>
                    <Image
                        style={styles.arrowImage}
                        source={require("@assets/images/arrow_down.png")}
                      />
                  </Pressable>

                    <ScrollView style={!isOpen ? styles.selectOuter : styles.selectOuterOpen}>
                        <View style={styles.scrlview}>
                          {mcq.lessons.map((item, index) => (
                            <View key={index}>
                              <Image
                                style={styles.qusticn}
                                source={require("@assets/images/qusticn.png")}
                              />
                              <Text style={styles.lesitem}>{item.title}</Text>
                            </View>
                          ))}
                        </View>
                    </ScrollView>

              </View>
            </View>
      
            <View style={styles.pointbox}>
              <Image
                style={styles.qusno}
                source={require("@assets/images/qusno.png")}
              />
              <Text style={styles.whitetext}>
                <Text style={styles.tcolr}>{mcq.points}</Text> Points in just
              </Text>
              <View style={styles.inlinetext}>
                <Text style={styles.mqus}>{mcq.questions}</Text>
                <Text style={styles.whitetext}>question</Text>
              </View>
              <Image
                style={styles.bgimg}
                source={require("@assets/images/poitboxbg.png")}
              />
            </View>
          </View>
        ))}

        <View style={styles.timerwrap}>
          <Text style={styles.timetext}>
            <Image
              style={styles.clkimg}
              source={require("@assets/images/timer.png")}
            />
            Timer
          </Text>
          <View style={styles.switchWrap}>
              <Switch
                trackColor={{false: '#7a6fd5', true: '#574cb4'}}
                thumbColor={isEnabled ? '#ffffff' : '#ffffff'}
                onValueChange={toggleSwitch}
                value={isEnabled}
              />
          </View>


          {/* <Pressable style={styles.switchbtn} onPress={gotoquestion}>
            <View style={styles.switchnob}></View>
          </Pressable> */}
        </View>
      </ScrollView>

      <Pressable
        style={styles.btn}
        onPress={() => navigation.navigate("TestsQuestion")}
      >
        <Text style={styles.btnText}>Start</Text>
      </Pressable>
    </Container>
  );
}

const styles = StyleSheet.create({
  clickOuter:{
    height:22,
    position:"relative",
  },
  selectOuter: {
   height:0,
  },
  arrowImage:{
    width:15,
    height:8,
    position:"absolute",
    right:6,
    top:5
  },
  selectOuterOpen:{
    height:140,
    marginTop:10
  },
  scrollview: {
    padding: 20,
    paddingTop: 100,
    paddingBottom: 2,
  },
  title: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 27,
    textAlign: "center",
  },
  subtitle: {
    color: "#FFF1E4",
    opacity: 0.7,
    textAlign: "center",
    marginBottom: 10,
  },
  yeloline: {
    width: 60,
    height: 4,
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 6,
  },
  mcontent: {
    paddingTop: 40,
  },
  lessdp: {
    backgroundColor: "#18191C",
    padding: 14,
    paddingLeft: 20,
    borderRadius: 10,
  },
  lestitle: {
    color: "#FFF1E4",
    fontFamily: "RobotoBold",
    fontSize: 14,
    height:38,
    overflow:"hidden"
  },
  lesoncount: {
    fontSize: 14,
    opacity: 0.7,
    fontFamily: "PoppinsRegular",
    paddingLeft: 4,
  },
  lesitem: {
    color: "#FFF1E4",
    fontFamily: "PoppinsRegular",
    fontSize: 12,
    opacity: 0.7,
    padding: 4,
    position: "relative",
    paddingLeft: 20,
  },
  qusticn: {
    width: 14,
    height: 9,
    position: "absolute",
    top: 8,
    left: 0,
  },
  lesscrol: {
    maxHeight: 185,
    flexGrow: 1,
  },
  scrlview: {
    height: 250,
    overflow: "scroll",
  },
  pointbox: {
    backgroundColor: "#18191C",
    marginTop: 20,
    padding: 20,
    borderRadius: 12,
    position: "relative",
    height: 150,
    overflow: "hidden",
  },
  whitetext: {
    color: "#fff",
    fontSize: 20,
    fontFamily: "PoppinsRegular",
  },
  tcolr: {
    color: "#62D4A1",
    fontFamily: "PoppinsSemiBold",
  },
  qusno: {
    width: 36,
    height: 33,
    position: "absolute",
    top: 52,
    left: 20,
  },
  mqus: {
    width: 38,
    color: "#fff",
    fontSize: 20,
    fontFamily: "PoppinsRegular",
    textAlign: "center",
    marginRight: 10,
  },
  inlinetext: {
    flexDirection: "row",
  },
  bgimg: {
    width: 150,
    height: 112,
    position: "absolute",
    bottom: 0,
    right: 0,
    zIndex: -2,
  },
  btn: {
    backgroundColor: "#787bd1",
    marginTop: 30,
    height: 50,
    borderRadius: 12,
    width: 280,
    textAlign: "center",
    marginLeft: "auto",
    marginRight: "auto",
    marginBottom: 20,
  },
  btnText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "bold",
    paddingTop: 15,
  },
  timerwrap: {
    flexDirection: "row",
    justifyContent: "center",
    paddingTop: 16,
    alignItems:"center"
  },
  clkimg: {
    width: 22,
    height: 18,
  },
  timetext: {
    color: "#6E7191",
    fontFamily: "PoppinsRegular",
    fontSize: 14,
  },
  switchbtn: {
    backgroundColor: "#4E4B66",
    width: 50,
    height: 24,
    borderRadius: 20,
    marginLeft: 20,
  },
  switchnob: {
    backgroundColor: "#FCFCFC",
    width: 20,
    height: 20,
    borderRadius: 20,
    margin: 2,
  },
});
