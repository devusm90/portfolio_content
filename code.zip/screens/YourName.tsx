import { BASE_URL } from "@env";
import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { useEffect, useState } from "react";
import {
  Alert, Image,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  View
} from "react-native";

import Container from "@components/Container";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function YourName({ navigation, fieldvalue}: { navigation:any, fieldvalue:any }) {
  const [username, setUsername] = useState(fieldvalue);

  useEffect(() => {
    getYourName()    
  }, [])

  //get username saved from DB
  const getYourName = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem('UserInfo') as string
      const parsed = JSON.parse(jsonValue);

      const savedresponse = await fetch(`${BASE_URL}/onboard/OnboardingData`, {
        method: "GET",
        headers: {
          'Authorization': 'Bearer ' +parsed.IdToken,  
          'Accept': 'application/json',
          'Content-Type': 'application/json'  
        }
      });

      const savedDataJson = await savedresponse.json();
      console.log("your name savedDataJson",savedDataJson);
      if(savedDataJson.data.fullName){
        const fieldvalue = savedDataJson.data.fullName;
        console.log("fieldvalue",fieldvalue);
      }
      return savedDataJson.success;   
    } catch (error) {
      console.error(error);
      return false;
    }
  }

  //Error message on wrong name
  const createTwoButtonAlert = () =>
    Alert.alert('Please enter a valid name', '', [      
      {text: 'OK', onPress: () => console.log('OK Pressed')},
    ]);

  
  //Name validation
  const nameValidation = async () => {
    if (!username.match(/^[a-zA-Z ]+$/)) {
      createTwoButtonAlert();
    } else {
      setYourName();
      
    }
  }
  

  const setYourName = async () => {    
    try {
      const jsonValue = await AsyncStorage.getItem('UserInfo') as string
      const parsed = JSON.parse(jsonValue);

      const userInfo = await AsyncStorage.getItem('OnboardingInfo') as string
      const userinfoparsed = JSON.parse(userInfo);    

      const onboardingInfo = {  
          purpose: userinfoparsed.purpose,
          fullName: username,
          branch: " ",
          course: {         
          }      
      };   



      console.log("purpose",userinfoparsed);
      await AsyncStorage.setItem('OnboardingInfo', JSON.stringify(onboardingInfo));
      console.log("OnboardingInfo your name",onboardingInfo);
      
      const postData = JSON.stringify({
        "purpose": userinfoparsed.purpose,
        "fullName": username,
        "branch": " ",
        "course": {         
        }      
      });

      const response = await fetch(`${BASE_URL}/onboard/OnboardingData`, {
        method: "POST",
        headers: {
          'Authorization': 'Bearer ' +parsed.IdToken,  
          'Accept': 'application/json',
          'Content-Type': 'application/json',   
          
        },
        body: postData
      });

      const saveDataJson = await response.json();
      console.log("your name post responsejson",saveDataJson);
      navigation.navigate("Branch",{
        paramKey: onboardingInfo.fullName
      })        
      return saveDataJson.success;
    } catch (error) {
      console.error(error);
      return false;
    }
    
};




  return (
    <Container>
      <View style={styles.container}>
        <View style={styles.top}>
          <Image
            style={styles.mainbanner}
            source={require("@assets/images/your-name.png")}
          />
        </View>
        <View style={styles.bottom}>
          <View style={styles.content}>
            <Image
              style={styles.logo}
              source={require("@assets/images/imtackl.png")}
            />
            <Text style={styles.maintitle}>and you are?</Text>
          </View>
          <SafeAreaView style={styles.namewrap}>            
            <TextInput
              style={styles.input}
              placeholder="Full Name"
              placeholderTextColor="#6E7191"
              onChangeText={(text) => {
                setUsername(text);                                             
              }} 

             
            />
            <Pressable style={styles.btn} onPress={nameValidation}>
              <Text style={styles.btnText}>Proceed</Text>
            </Pressable>
          </SafeAreaView>
        </View>
      </View>
    </Container>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "column",
  },
  top: {
    flex: 1,
  },
  bottom: {
    flex: 1.3,
    backgroundColor: "#18191C",
  },
  maintitle: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 36,
    textAlign: "center",
    marginTop: 10,
    marginBottom: 10,
  },
  mainbanner: {
    width: 360,
    height: 220,
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 160,
    marginBottom: -58,
    position: "relative",
    zIndex: 999,
  },

  logo: {
    width: 180,
    height: 30,
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 20,
  },
  content: {
    backgroundColor: "#18191C",
    paddingBottom: 40,
    paddingTop: 60,
  },
  input: {
    borderColor: "#6E7191",
    borderWidth: 1,
    backgroundColor: "#0B0B13",
    color: "#fff",
    height: 50,
    fontSize: 16,
    width: 280,
    marginLeft: "auto",
    marginRight: "auto",
    borderRadius: 10,
    paddingLeft: 10,
  },
  btn: {
    backgroundColor: "#787bd1",
    marginTop: 20,
    height: 50,
    borderRadius: 12,
    width: 280,
    textAlign: "center",
    marginLeft: "auto",
    marginRight: "auto",
  },
  btnText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "bold",
    paddingTop: 15,
  },
  namewrap: {
    paddingTop: 2,
  },
});
