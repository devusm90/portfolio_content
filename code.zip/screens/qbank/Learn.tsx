import BottomNav from "@components/BottomNav";
import Container from "@components/Container";
import HeaderNav from "@components/HeaderNav";
import React, { useEffect, useState } from "react";
import {
  Dimensions,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View
} from "react-native";
// import * as Progress from "react-native-progress";


const width = Dimensions.get("window").width; //full width



// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function Learn({ navigation }: { navigation: any }) {
  // const [isLoading, setLoading] = useState(true);
  const [data, setData] = useState([]);

  // type Qbank = {
  //   brand: string;
  //   title: string;
  //   category: string;
  //   price: number;
  //   stock: number;
  // };
  
  useEffect(() => {  
    getQbankList();
    alert("ddd");
  }, [])

  // get question bank data
  const getQbankList = async () => {
    try {
      const response = await fetch(`https://jsonplaceholder.typicode.com/users`);    
      const json = await response.json();
      console.log("dummy",response);
      console.log("data",json);
      setData(json);      

      return json.success;   
    } catch (error) {
      console.error(error);
    } 
  }

  return (
    <Container>
      <HeaderNav />
      <View style={styles.tabs}>
        <Pressable
          style={styles.tabtnblue}
          onPress={() => navigation.navigate("Learn")}
        >
          <Text style={styles.btnwhite}>Q-Bank</Text>
        </Pressable>
        <Pressable
          style={styles.tabtn}
          onPress={() => navigation.navigate("Flashlist")}
        >
          <Text style={styles.btnText}>Flashcard</Text>
        </Pressable>
        <Pressable
          style={styles.tabtn}
          onPress={() => navigation.navigate("Tests")}
        >
          <Text style={styles.btnText}>Tests</Text>
        </Pressable>
      </View>
      <ScrollView>
        <Text style={styles.lastatm}>Last Attempt</Text>
        <View style={styles.col2}>
          <View style={styles.s4}>
            <Image
              style={styles.donut}
              source={require("@assets/images/donut-chart.png")}
            />
          </View>
          <View style={styles.s8}>
            <Text style={styles.atmhead}>Examination Of Eye</Text>
            <Text style={styles.atmsub}>subject</Text>
            <Text style={styles.atmsts}>
              {/* {price}/{stock} Chapters */}
              Chapters
            </Text>
            <Pressable onPress={() => navigation.navigate("Learn")}>
              <Text style={styles.conlear}>
                Continue Learning{" "}
                <Image
                  style={styles.rightblue}
                  source={require("@assets/images/right-blue.png")}
                />
              </Text>
            </Pressable>
          </View>
        </View>
        {/* {isLoading ? (<ActivityIndicator />) : (       */}
         {/* {data.map((item,index) => (
          <View key={index}>
            <Text style={styles.lastatm}>{item.username}</Text>
            <ScrollView style={styles.horzwrap} horizontal={true}>
                <Pressable
                  style={styles.qbank}
                  onPress={() =>
                    navigation.navigate("QbankMain")
                  }
                >
                  <Image
                    style={styles.rocket}
                    source={require("@assets/images/rocket.png")}
                  />
                  <Text style={styles.qtitle}>{item}</Text>
                  <Text style={styles.atmsts}>
                    {item.phone}/{item.name} Chapters
                  </Text>
                  <View style={styles.percentage}>
                    <Progress.Circle
                      fill="#25272c"
                      strokeCap="square"
                      showsText={true}
                      unfilledColor="#25272c"
                      borderWidth={0}
                      direction="counter-clockwise"
                      color="#62D4A1"
                      size={60}
                      progress={0.4}
                      indeterminate={false}
                      animated={true}
                    />
                  </View>
                </Pressable>
            </ScrollView>
          </View>
        ))} */}
      </ScrollView>
      <BottomNav />
    </Container>
  );
}

const styles = StyleSheet.create({
  percentage: {
    position: "absolute",
    right: -10,
    top: -10,
    borderRadius: 50,
    width: 60,
    height: 60,
  },
  tabs: {
    flexDirection: "row",
    justifyContent: "space-between",
    backgroundColor: "#000",
    marginTop: 10,
    marginRight: 20,
    marginLeft: 20,
    padding: 2,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#4E4B66",
  },
  tabtn: {
    borderRadius: 6,
    padding: 10,
    margin: 2,
    flex: 1,
  },
  tabtnblue: {
    backgroundColor: "#777BD1",
    borderRadius: 6,
    padding: 10,
    margin: 2,
    flex: 1,
  },
  btnwhite: {
    color: "#fff",
    textAlign: "center",
    fontFamily: "PoppinsBold",
    fontSize: 14,
  },
  btnText: {
    color: "#777BD1",
    textAlign: "center",
    fontFamily: "PoppinsBold",
    fontSize: 14,
  },
  lastatm: {
    color: "#FFF1E4",
    marginLeft: 22,
    marginTop: 20,
    marginBottom: 10,
    fontFamily: "PoppinsSemiBold",
    fontSize: 14,
    opacity: 0.7,
  },
  col2: {
    backgroundColor: "#18191C",
    padding: 10,
    marginLeft: 20,
    marginRight: 20,
    flexDirection: "row",
    borderRadius: 10,
  },
  s4: {
    marginTop: 0,
    flex: 1,
  },
  donut: {
    width: 100,
    height: 95,
  },
  s8: {
    paddingLeft: 10,
    marginTop: 0,
    flex: 2,
  },
  atmhead: {
    color: "#FFF1E4",
    fontSize: 17,
    fontFamily: "PoppinsBold",
  },
  atmsub: {
    color: "#FFF1E4",
    fontSize: 12,
    fontFamily: "PoppinsBold",
  },
  atmsts: {
    color: "#FFF1E4",
    fontSize: 12,
    opacity: 0.7,
    fontFamily: "PoppinsRegular",
  },
  conlear: {
    color: "#777BD1",
    fontSize: 12,
    fontFamily: "PoppinsRegular",
    marginTop: 10,
  },
  rightblue: {
    width: 16,
    height: 16,
    paddingLeft: 10,
  },
  horzwrap: {
    paddingTop: 1,
    paddingLeft: 20,
  },
  qbank: {
    backgroundColor: "#31333B",
    padding: 16,
    borderRadius: 10,
    width: width / 2 - 24,
    marginLeft: 0,
    marginRight: 10,
    overflow: "hidden",
  },
  rocket: {
    width: 30,
    height: 33,
    marginTop: 10,
    marginBottom: 10,
  },
  qtitle: {
    color: "#FFF1E4",
    fontFamily: "PoppinsSemiBold",
    fontSize: 18,
  },
});
