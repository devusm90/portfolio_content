import React from "react";
import {
  Dimensions,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import qbankQuestion from "@data/qbankquestions.json";

const width = Dimensions.get("window").width;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function Streak({ navigation }: { navigation: any }) {
  const congrat = () => {
    navigation.navigate("QbankCongrat");
  };

  // const gotoStreak = () => {
  //   navigation.navigate("Streak");
  // };

  return (
    <View style={styles.maincontainer}>
      <ScrollView contentContainerStyle={styles.scrollview}>
        {qbankQuestion.map((quscat, index) => (
          <View key={index}>
            <View style={styles.col3}>
              <Image
                style={styles.taclimg}
                source={require("@assets/images/tackl-icon.png")}
              />
              <View style={styles.inline}>
                <Text style={styles.qstyl}>Q</Text>
                <Text style={styles.count}>1/{quscat.questions.length}</Text>
              </View>

              <View style={styles.inline}>
                <Pressable style={styles.tpimg} onPress={congrat}>
                  <Image
                    style={styles.bkmark}
                    source={require("@assets/images/bkmark.png")}
                  />
                </Pressable>
                <Pressable
                  style={styles.tpimg}
                  onPress={() => navigation.navigate("SolveMcq")}
                >
                  <Image
                    style={styles.clse}
                    source={require("@assets/images/close2.png")}
                  />
                </Pressable>
              </View>
            </View>

            {quscat.questions.map((quiz, index) => (
              <View key={index}>
                <View style={styles.queswrp}>
                  <Text style={styles.qust}>{quiz.title}</Text>
                  <Image style={styles.qustimg} source={{ uri: quiz.image }} />
                </View>

                <Pressable style={styles.optwrap} onPress={congrat}>
                  <Text style={styles.mark}>A</Text>
                  <Text style={styles.opt}>{quiz.opt1}</Text>
                </Pressable>

                <Pressable style={styles.optwrap} onPress={congrat}>
                  <Text style={styles.mark}>B</Text>
                  <Text style={styles.opt}>{quiz.opt2}</Text>
                </Pressable>

                <Pressable style={styles.optwrap} onPress={congrat}>
                  <Text style={styles.mark}>C</Text>
                  <Text style={styles.opt}>{quiz.opt3}</Text>
                </Pressable>

                <Pressable style={styles.optwrap} onPress={congrat}>
                  <Text style={styles.mark}>D</Text>
                  <Text style={styles.opt}>{quiz.opt4}</Text>
                </Pressable>
              </View>
            ))}
          </View>
        ))}

        <Text style={styles.title}>Explanation</Text>
        <Image
          style={styles.yeloline}
          source={require("@assets/images/yellow-line.png")}
        />
        <View style={styles.invebox}>
          <Text style={styles.invtitle}>Investigations</Text>
          <Text style={styles.intext}>Haemoglobin 78 g/L (130–175)</Text>
          <Text style={styles.intext}>
            White cell count 3.4 × 109/L (3.0–10.0)
          </Text>
          <Text style={styles.intext}>Platelet count 80 × 109/L (150–400)</Text>
          <Text style={styles.intext}>
            Corrected calcium 2.71 mmol/L (2.2–2.6)
          </Text>
          <Text style={styles.intext}>Albumin 36 g/L (35–50)</Text>
        </View>

        <Pressable onPress={congrat}>
          <Text style={styles.anydoubt}>Any Doubts?</Text>
        </Pressable>

        <View style={styles.relacrd}>
          <Text style={styles.relytitle}>
            We may suggest you to revise this topics
          </Text>
          <Image
            style={styles.relyimg}
            source={require("@assets/images/relayimg.png")}
          />
          <Text style={styles.relytype}>Types of Relation</Text>
          <Text style={styles.relytime}>12 Mints</Text>
        </View>
      </ScrollView>

      <View style={styles.btmnavwrp}>
        <Pressable onPress={() => navigation.navigate("QuestionMcq")}>
          <Image
            style={styles.leftarw}
            source={require("@assets/images/leftarow.png")}
          />
        </Pressable>

        <Pressable onPress={congrat}>
          <Image
            style={styles.btmqus}
            source={require("@assets/images/quesicon.png")}
          />
        </Pressable>

        <Pressable onPress={congrat}>
          <Image
            style={styles.btmbkm}
            source={require("@assets/images/bkmark.png")}
          />
        </Pressable>

        <Pressable style={styles.btn} onPress={congrat}>
          <Text style={styles.btnText}>Next</Text>

          <Image
            style={styles.btnaru}
            source={require("@assets/images/right-arrow.png")}
          />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  maincontainer: {
    flex: 1,
  },
  scrollview: {
    paddingBottom: 2,
  },
  col3: {
    backgroundColor: "#0E0F1B",
    paddingTop: 60,
    paddingBottom: 10,
    flexDirection: "row",
    paddingLeft: 10,
    paddingRight: 10,
    justifyContent: "space-between",
  },
  inline: {
    flexDirection: "row",
  },
  taclimg: {
    width: 30,
    height: 30,
  },
  bkmark: {
    width: 20,
    height: 24,
  },
  clse: {
    width: 20,
    height: 20,
    position: "relative",
    top: 3,
  },
  tpimg: {
    paddingLeft: 10,
    paddingRight: 10,
  },
  qstyl: {
    fontFamily: "RecoletaMedium",
    color: "#FFF1E4",
    fontSize: 22,
    paddingRight: 10,
  },
  count: {
    fontFamily: "RobotoBold",
    color: "#FFF1E4",
    fontSize: 14,
    paddingTop: 4,
  },
  queswrp: {
    backgroundColor: "#0E0F1B",
    padding: 20,
    marginBottom: 20,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  qust: {
    fontFamily: "PoppinsRegular",
    color: "#FFF1E4",
    fontSize: 18,
  },
  qustimg: {
    width: width - 40,
    height: 300,
    marginTop: 20,
    borderRadius: 20,
  },
  optwrap: {
    padding: 4,
    position: "relative",
    paddingLeft: 60,
    marginLeft: 20,
    marginRight: 20,
    borderWidth: 1,
    marginBottom: 10,
  },
  opt: {
    fontFamily: "RobotoRegular",
    color: "#FFF1E4",
    fontSize: 16,
  },
  mark: {
    position: "absolute",
    fontFamily: "RecoletaMedium",
    color: "#6E7191",
    fontSize: 20,
    top: 4,
    left: 24,
  },
  btn: {
    backgroundColor: "#787bd1",
    height: 40,
    borderRadius: 12,
    width: 140,
    textAlign: "center",
    position: "relative",
  },
  btnText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
    paddingTop: 8,
    paddingLeft: 40,
  },
  btnaru: {
    width: 24,
    height: 17,
    position: "absolute",
    top: 12,
    right: 30,
  },
  title: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 27,
    textAlign: "center",
    marginTop: 40,
    marginBottom: 0,
  },
  yeloline: {
    width: 60,
    height: 4,
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 6,
  },
  invebox: {
    backgroundColor: "#18191C",
    padding: 20,
    margin: 20,
    borderRadius: 16,
  },
  invtitle: {
    fontFamily: "PoppinsSemiBold",
    color: "#FFF1E4",
    fontSize: 16,
    opacity: 0.7,
    marginBottom: 10,
  },
  intext: {
    fontFamily: "PoppinsRegular",
    color: "#FFF1E4",
    fontSize: 14,
  },
  anydoubt: {
    fontFamily: "PoppinsSemiBold",
    color: "#777BD1",
    fontSize: 14,
    textAlign: "center",
  },
  relacrd: {
    margin: 20,
    padding: 20,
    backgroundColor: "#18191C",
  },
  relytitle: {
    fontFamily: "PoppinsSemiBold",
    color: "#FFF1E4",
    fontSize: 14,
    textAlign: "center",
  },
  relyimg: {
    width: 80,
    height: 80,
    marginLeft: "auto",
    marginRight: "auto",
  },
  relytype: {
    fontFamily: "PoppinsSemiBold",
    color: "#FFF1E4",
    fontSize: 20,
    textAlign: "center",
  },
  relytime: {
    fontFamily: "PoppinsRegular",
    color: "#FFF1E4",
    fontSize: 14,
    opacity: 0.7,
    textAlign: "center",
  },
  btmnavwrp: {
    backgroundColor: "#18191C",
    padding: 10,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  leftarw: {
    width: 25,
    height: 21,
    marginTop: 14,
    marginLeft: 10,
  },
  rightarw: {
    width: 16,
    height: 13,
  },
  btmqus: {
    width: 24,
    height: 24,
    marginTop: 10,
  },
  btmbkm: {
    width: 20,
    height: 24,
    marginTop: 10,
  },
});
