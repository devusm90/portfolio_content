import React, { useState } from "react";
import {
  Alert, Dimensions,
  Image, Modal, Pressable,
  ScrollView,
  StyleSheet,
  Text, View
} from "react-native";

import qbankQuestion from "@data/qbankquestions.json";
import ImageZoom from 'react-native-image-pan-zoom';


const width = Dimensions.get("window").width; //full width

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function QuestionMcq({ navigation }: { navigation: any }) {
  const gotoStreak = () => {
    navigation.navigate("Streak");
  };

  const [modalVisible, setModalVisible] = useState(false);




  
  return (
    <ScrollView contentContainerStyle={styles.scrollview}>
      {qbankQuestion.map((quscat, index) => (
        <View key={index}>
          <View style={styles.col3}>
            <Image
              style={styles.taclimg}
              source={require("@assets/images/tackl-icon.png")}
            />
            <View style={styles.inline}>
              <Text style={styles.qstyl}>Q</Text>
              <Text style={styles.count}>1/{quscat.questions.length}</Text>
            </View>

            <View style={styles.inline}>
              <Pressable style={styles.tpimg} onPress={gotoStreak}>
                <Image
                  style={styles.bkmark}
                  source={require("@assets/images/bkmark.png")}
                />
              </Pressable>
              <Pressable
                style={styles.tpimg}
                onPress={() => navigation.navigate("SolveMcq")}
              >
                <Image
                  style={styles.clse}
                  source={require("@assets/images/close2.png")}
                />
              </Pressable>
            </View>
          </View>

          {quscat.questions.map((quiz, index) => (
            <View key={index}>
              <View style={styles.queswrp}>
                <Text style={styles.qust}>{quiz.title}</Text>
                



                <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          Alert.alert('Modal has been closed.');
          setModalVisible(!modalVisible);
        }}>
        <View style={styles.centeredView}>

          <Pressable style={styles.modalcls} onPress={() => setModalVisible(!modalVisible)}>
            <Image style={styles.clsebtn} source={require("@assets/images/close2.png")} />
          </Pressable>

          <ImageZoom cropWidth={Dimensions.get('window').width} cropHeight={300} imageWidth={300} imageHeight={200}>
            <Image style={{width:Dimensions.get('window').width, height:300}} source={{uri: quiz.image}}/>
          </ImageZoom>

          
        </View>
      </Modal>

      <Pressable onPress={() => setModalVisible(true)}>
        <Image style={styles.quzimg} source={{uri: quiz.image}}/>
      </Pressable>





              </View>

              <Pressable style={styles.optwrap} onPress={gotoStreak}>
                <Text style={styles.mark}>A</Text>
                <Text style={styles.opt}>{quiz.opt1}</Text>
              </Pressable>

              <Pressable style={styles.optwrap} onPress={gotoStreak}>
                <Text style={styles.mark}>B</Text>
                <Text style={styles.opt}>{quiz.opt2}</Text>
              </Pressable>

              <Pressable style={styles.optwrap} onPress={gotoStreak}>
                <Text style={styles.mark}>C</Text>
                <Text style={styles.opt}>{quiz.opt3}</Text>
              </Pressable>

              <Pressable style={styles.optwrap} onPress={gotoStreak}>
                <Text style={styles.mark}>D</Text>
                <Text style={styles.opt}>{quiz.opt4}</Text>
              </Pressable>
            </View>
          ))}
        </View>
      ))}

      <Pressable style={styles.btn} onPress={gotoStreak}>
        <Text style={styles.btnText}>Go to Streak</Text>
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scrollview: {
    paddingBottom: 2,
  },
  col3: {
    backgroundColor: "#0E0F1B",
    paddingTop: 60,
    paddingBottom: 10,
    flexDirection: "row",
    paddingLeft: 10,
    paddingRight: 10,
    justifyContent: "space-between",
  },
  inline: {
    flexDirection: "row",
  },
  taclimg: {
    width: 30,
    height: 30,
  },
  bkmark: {
    width: 20,
    height: 24,
  },
  clse: {
    width: 20,
    height: 20,
    position: "relative",
    top: 3,
  },
  tpimg: {
    paddingLeft: 10,
    paddingRight: 10,
  },
  qstyl: {
    fontFamily: "RecoletaMedium",
    color: "#FFF1E4",
    fontSize: 22,
    paddingRight: 10,
  },
  count: {
    fontFamily: "RobotoBold",
    color: "#FFF1E4",
    fontSize: 14,
    paddingTop: 4,
  },
  queswrp: {
    backgroundColor: "#0E0F1B",
    padding: 20,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  qust: {
    fontFamily: "PoppinsRegular",
    color: "#FFF1E4",
    fontSize: 18,
  },
  qustimg: {
    width: width - 40,
    height: 300,
    marginTop: 20,
    borderRadius: 20,
  },
  optwrap: {
    borderColor: "#4E4B66",
    backgroundColor: "#0B0B13",
    borderWidth: 1,
    borderRadius: 16,
    padding: 10,
    position: "relative",
    paddingLeft: 60,
    minHeight: 65,
    margin: 20,
    marginBottom: 1,
  },
  opt: {
    fontFamily: "PoppinsSemiBold",
    color: "#FFF1E4",
    fontSize: 16,
  },
  mark: {
    position: "absolute",
    fontFamily: "RecoletaMedium",
    color: "#6E7191",
    fontSize: 20,
    top: 20,
    left: 24,
  },
  btn: {
    backgroundColor: "#787bd1",
    marginTop: 30,
    height: 50,
    borderRadius: 12,
    width: 280,
    textAlign: "center",
    marginLeft: "auto",
    marginRight: "auto",
    marginBottom: 20,
  },
  btnText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "bold",
    paddingTop: 15,
  },

  quzimg:{
    width:width-40,
    height:300,
    borderRadius:20,
    marginTop:10,

  },
  centeredView:{
    backgroundColor:'#0E0F1B',
    padding:20,
    flex:1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  clsebtn:{
    width: 20,
    height: 20,
    marginLeft:'auto',
    margin:20,
  },
  modalcls:{
    backgroundColor:'#0E0F1B',
    textAlign:'right',
    width:width,
  }


});
