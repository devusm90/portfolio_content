import Container from "@components/Container";
import { BASE_URL } from "@env";
import { StatusBar } from "expo-status-bar";
import React, { useEffect, useState } from "react";
import { ActivityIndicator, Dimensions, Image, Pressable, StyleSheet, Text, View } from "react-native";
import Carousel, { Pagination } from "react-native-snap-carousel";




export const SLIDER_WIDTH = Dimensions.get("window").width;
export const SLIDER_HEIGHT = Dimensions.get("window").height;
export const ITEM_WIDTH = Math.round(SLIDER_WIDTH * 0.7);




  const CarouselCardItem = ({ item, index }) => {
    // console.log("item....",item);
    return (
      <View key={index}>
        <Image
            style={styles.welcomeImage}
            source={{uri: `${item}`}}
          />          
      </View>
    );
  };



// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function Welcome({ navigation }: { navigation: any }) {
  const signup = () => {
    navigation.navigate("SignUp");
  };


  const [isLoading, setLoading] = useState(true);
  const [data, setData] = useState([]);

  const getMovies = async () => {
    try {
      const response = await fetch(`${BASE_URL}/welcome`);
      const json = await response.json();
      
      setData(json.data);
    } catch (error) {
      // console.error(error);
    } finally {
      setLoading(false);
    }
  };
  // console.log("isLoading",isLoading);
  

  useEffect(() => {
    getMovies();
  }, []);


  const [index, setIndex] = React.useState(0);
  const isCarousel = React.useRef(null);

  return (

    <Container>
      <StatusBar style="light" backgroundColor="#0b0b13" />
      <Pressable style={styles.btn} onPress={signup}>
        <Text style={styles.btnText}>Skip</Text>
      </Pressable>

      <View style={styles.logowrap}>
        <Image
          style={styles.logo}
          source={require("@assets/images/tackl.png")}
        />
      </View>
      <View style={styles.container}>
        {isLoading ? (
        <ActivityIndicator />
      ) : (
        <View style={styles.wrap}>
            <Carousel
            layout="default"
            ref={isCarousel}
            data={data}
            renderItem={CarouselCardItem}
            sliderWidth={SLIDER_WIDTH-40}
            sliderHeight={335}
            itemWidth={SLIDER_WIDTH}
            onSnapToItem={(index) => setIndex(index)}
            useScrollView={true}
            activeSlideOffset={0}
            autoplay={true}
            lockScrollWhileSnapping={true} 
          />

          <View style={styles.dotContainer}>
            <Pagination
              dotsLength={data.length}
              activeDotIndex={index}
              carouselRef={isCarousel}
              dotStyle={{
                width: 10,
                height: 10,
                borderRadius: 50,
                marginHorizontal: 0,
                backgroundColor: "#ccc",
                
              }}
              inactiveDotOpacity={0.4}
              inactiveDotScale={0.6}
              tappableDots={true}
            />
          </View>

          
          </View>
          )}
      </View>
    </Container>
  );
}

const styles = StyleSheet.create({
  welcomeImage:{
    width:SLIDER_WIDTH-50,
    height:335
  },
  wrap:{
    padding:20,
    display:"flex",
    alignItems: "center",
    flexDirection:"column",
    justifyContent: "center",
  },

  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding:20,
  },
  title: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 27,
    textAlign: "center",
    marginTop: 120,
    marginBottom: 10,
  },
  btn: {
    padding: 20,
    paddingTop: 50,
  },
  btnText: {
    color: "#FFF1E4",
    textAlign: "right",
    fontSize: 18,
  },
  logo: {
    width: 150,
    height: 41,
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 20,
  },
  logowrap: {
    paddingTop: 10,
    paddingBottom: 40,
  },
});
