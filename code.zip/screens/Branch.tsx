import { BASE_URL } from "@env";
import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { useEffect, useState } from "react";
import {
  Alert, Dimensions, Image,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  View
} from "react-native";

import Container from "@components/Container";
import RadioButtonGroup, { RadioButtonItem } from "expo-radio-button";

const width = Dimensions.get("window").width; //full width

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function Branch(this: any, { navigation, fieldvalue, route }: { navigation: any, fieldvalue:any ,route:any}) {
  const [coursename, setCourse] = useState(fieldvalue);
  const yourname = route.params.paramKey;

  useEffect(() => {
    getBranchName()    
  }, [])


  //get branch name saved from DB
  const getBranchName = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem('UserInfo') as string
      const parsed = JSON.parse(jsonValue);


      const savedresponse = await fetch(`${BASE_URL}/onboard/OnboardingData`, {
        method: "GET",
        headers: {
          'Authorization': 'Bearer ' +parsed.IdToken,  
          'Accept': 'application/json',
          'Content-Type': 'application/json'  
        }
      });

      const savedDataJson = await savedresponse.json();
      console.log("your name savedDataJson",savedDataJson);

      if(savedDataJson.data.name){
        const fieldvalue = savedDataJson.data.name;
        console.log("fieldvalue",fieldvalue);
      }

      if(savedDataJson.data.fullName){
        const username = savedDataJson.data.fullName;
        console.log("username",username);
      }


      return savedDataJson.success;   
    } catch (error) {
      console.error(error);
      return false;
    }
  }

  const alertTrigger = () =>{
    Alert.alert('Please select a Course', '', [      
      {text: 'OK', onPress: () => console.log('OK Pressed')},
    ]);
  }
  const emptyCheck = () =>{
    if(coursename){
      setBranchName()
    }else{
      alertTrigger()
    }
  }


//Save post branch name data in DB  
  const setBranchName = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem('UserInfo') as string
      const parsed = JSON.parse(jsonValue);

      const userInfo = await AsyncStorage.getItem('OnboardingInfo') as string
      const userinfoparsed = JSON.parse(userInfo);
      
      const onboardingInfo = {
        purpose: userinfoparsed.purpose,
        fullName: userinfoparsed.fullName,
        branch: "Medical",
        course: {    
            name: coursename     
        }      
      };

      await AsyncStorage.setItem('OnboardingInfo', JSON.stringify(onboardingInfo));
      console.log("OnboardingInfo branch",onboardingInfo);      
      
      const postData = JSON.stringify({
        "purpose": userinfoparsed.purpose,
        "fullName": userinfoparsed.fullName,
        "branch": "Medical",
        "course": {       
          "name": coursename       
        }      
      });

      const response = await fetch(`${BASE_URL}/onboard/OnboardingData`, {
        method: "POST",
        headers: {
          'Authorization': 'Bearer ' +parsed.IdToken,  
          'Accept': 'application/json',
          'Content-Type': 'application/json'             
        },
        body: postData
      });

    const json = await response.json();
    console.log("branch json",json);
    navigation.navigate("PostGraduation");

    // if(json){
    //   const fieldvalue = json.data.course.country;
    //   const state = json.data.course.state;
    //   const college = json.data.course.college;
    //   const year = json.data.course.year;
    //   navigation.navigate("PostGraduation",{
    //     paramKey: fieldvalue,
    //     paramKey1: state,
    //     paramKey2: college,
    //     paramKey3: year,
    //   })
    //   console.log("year postgraduation",year);
    // }else{
    //   navigation.navigate("PostGraduation")
    // }
    return json.success;
    } catch (error) {
      console.error(error);
      return false;
    }
    
  }

  return (
    <Container>      

      <View style={styles.topading}>
        <Text style={styles.title}>
          Hi {yourname}{" "}
          <Image
            style={styles.chalkimg}
            source={require("@assets/images/chalk-mark.png")}
          />
        </Text>
        <Image
          style={styles.yeloline}
          source={require("@assets/images/yellow-line.png")}
        />

        <SafeAreaView style={styles.cant}>
          <Text style={styles.whitetxt}>Can&apos;t wait to get</Text>
          <Text style={styles.whitetxt}>
            <Image
              style={styles.takicon}
              source={require("@assets/images/tackl-icon.png")}
            />
            <Text style={styles.bold}>tackling</Text> together!
          </Text>
          <View style={styles.curvewrap}>
            <Image
              style={styles.curve}
              source={require("@assets/images/curve.png")}
            />
          </View>
        </SafeAreaView>

        <SafeAreaView style={styles.content}>
          <Text style={styles.frmlabel}>Please select the Branch</Text>
          <RadioButtonGroup
            containerStyle={{ marginBottom: 0 }}
            selected={coursename}
            onSelected={(value: React.SetStateAction<undefined>) => setCourse(value)}
            containerOptionStyle={{ margin: 8 }}
            radioBackground="#fff"
            radioStyle={{
              backgroundColor: "#777BD1",
              borderWidth: 5,
              borderColor: "#777BD1",
              opacity: 1,
            }}
            size={26}
          >
            <RadioButtonItem
              value="SS Surgery"
              label={<Text style={styles.label}>SS Surgery</Text>}
            />
            <RadioButtonItem
              value="SS Medicine"
              label={<Text style={styles.label}>SS Medicine</Text>}
            />
            <RadioButtonItem
              value="Medical PG"
              label={<Text style={styles.label}>Medical PG</Text>}
            />
          </RadioButtonGroup>
          
        </SafeAreaView>
        <Pressable style={styles.btn} onPress={emptyCheck}>
              <Text style={styles.btnText}>Proceed</Text>
            </Pressable>
      </View>
    </Container>
  );
}

const styles = StyleSheet.create({
  topading: {
    paddingTop: 0,
    flex: 1,
    flexDirection: "column",
    justifyContent: "center",
  },
  title: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 27,
    textAlign: "center",
  },
  chalkimg: {
    width: 9,
    height: 28,
    position: "relative",
    left: 20,
  },
  yeloline: {
    width: 60,
    height: 4,
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 10,
  },
  whitetxt: {
    color: "#fff",
    textAlign: "center",
    fontSize: 24,
    fontFamily: "PoppinsRegular",
  },
  bold: {
    fontWeight: "bold",
  },
  cant: {
    paddingTop: 60,
  },
  takicon: {
    width: 20,
    height: 20,
    position: "relative",
    left: -10,
  },
  curvewrap: {
    textAlign: "right",
    marginTop: 40,
    marginBottom: 40,
    display: "flex",
    alignItems: "center",
  },
  curve: {
    width: 80,
    height: 61,
    alignSelf: "flex-end",
    marginRight: 40,
  },
  content: {
    padding: 20,
    backgroundColor: "#18191C",
    margin: 20,
    marginBottom: 0,
    borderRadius: 16,
  },
  frmlabel: {
    color: "#FFF1E4",
    fontFamily: "PoppinsRegular",
    fontSize: 14,
    padding: 20,
  },
  label: {
    color: "#6E7191",
    fontSize: 15,
    fontFamily: "PoppinsSemiBold",
    paddingLeft: 10,
  },
  btn: {
    backgroundColor: "#787bd1",
    marginTop: 30,
    height: 50,
    borderRadius: 12,
    width: 280,
    textAlign: "center",
    marginLeft: "auto",
    marginRight: "auto",
    position: "absolute",
    left: width / 2 - 140,
    bottom: 0,
  },
  btnText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "bold",
    paddingTop: 15,
  },
  alignment: {},
});
