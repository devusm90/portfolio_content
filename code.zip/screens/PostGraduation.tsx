import { BASE_URL } from "@env";
import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { useCallback, useEffect, useState } from "react";
import {
  Alert, Dimensions,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  View
} from "react-native";

import Container from "@components/Container";
import RadioButtonGroup, { RadioButtonItem } from "expo-radio-button";
import DropDownPicker from "react-native-dropdown-picker";

const width = Dimensions.get("window").width; //full width
const height = Dimensions.get("window").height; //full height

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function Branch({ navigation , route }: { navigation: any, route:any }) {
  //route.params.paramKey
  const [country, setCountry] = useState();


  useEffect(() => {
    getPgData()    
  }, [])

  //get post graduation data saved from DB
  const getPgData = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem('UserInfo') as string
      const parsed = JSON.parse(jsonValue);


      const savedresponse = await fetch(`${BASE_URL}/onboard/OnboardingData`, {
        method: "GET",
        headers: {
          'Authorization': 'Bearer ' +parsed.IdToken,  
          'Accept': 'application/json',
          'Content-Type': 'application/json'  
        }
      });

      const savedDataJson = await savedresponse.json();
      console.log("PG savedDataJson",savedDataJson);

      if(savedDataJson.data.course.country){
        const countryvalue = savedDataJson.data.course.country;
        console.log("countryvalue",countryvalue);
      }

      if(savedDataJson.data.course.state){
        const statevalue = savedDataJson.data.course.state;
        console.log("statevalue",statevalue);
      }

      if(savedDataJson.data.course.college){
        const collegevalue = savedDataJson.data.course.college;
        console.log("collegevalue",collegevalue);
      }

      if(savedDataJson.data.course.year){
        const yearvalue = savedDataJson.data.course.year;
        console.log("yearvalue",yearvalue);
      }
      return savedDataJson.success;   
    } catch (error) {
      console.error(error);
      return false;
    }
  }

  const alertTrigger = () =>{
    Alert.alert('Please fill the fields', '', [      
      {text: 'OK', onPress: () => console.log('OK Pressed')},
    ]);
  }

  const emptyCheck = () =>{
    if(country){     
      setPgData();
    }else{
      alertTrigger()
    }
  }

  const getStateData = async () => {
  const response = await fetch("https://reqres.in/api/users?page=2", {
      method: "GET",
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',           
      }
    });

    const indstatejson = await response.json();
    // console.log("indstatejson",indstatejson);
    // const statelist = indstatejson.data.map((item: any) => ({
    //   label: item.first_name, value: item.last_name
    // }))
    // setItems(statelist);    
  }

  const collegeData = async (value : string) => {
  const response = await fetch(`${BASE_URL}/list/getCollegeList?stateCode=` + value, {
      method: "GET",
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',           
      }
    });
    const indcollegejson = await response.json();
    // console.log("indstatejson",indcollegejson);
    const collegelist = indcollegejson.map((item: any) => ({
      label: item.name, value: item.id
    }))
    // console.log("collegelist",collegelist);
    setCollegeItems(collegelist); 
  }

  const yearData = async () => {
  const response = await fetch("https://reqres.in/api/users?page=2", {
      method: "GET",
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',           
      }
    });
    
    const indstatejson = await response.json();
    const currentYear  = new Date().getFullYear();
    const yearsList = Array(currentYear - (currentYear - 10)).fill('').map((v,idx) => ({
      label: currentYear - idx, value: currentYear - idx
    })); 
    // console.log("yearsList",yearsList );
    
    // const yearlist = indstatejson.data.map((item: any) => ({
    //   label: item.email, value: item.id
    // }))
    setYearItems(yearsList); 
  }

  //Save post graduation data in DB
  const setPgData = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem('UserInfo') as string
      const parsed = JSON.parse(jsonValue);

      const userInfo = await AsyncStorage.getItem('OnboardingInfo') as string
      const userinfoparsed = JSON.parse(userInfo);      
          
      const onboardingInfo = {  
        purpose: userinfoparsed.purpose,  
        fullName: userinfoparsed.fullName,    
        branch: "Medical",   
        course:{          
          name:userinfoparsed.name,
          country: country,
          state: statevalue,
          college: collegevalue,
          year: yearvalue          
        }     
      }               

      await AsyncStorage.setItem('OnboardingInfo', JSON.stringify(onboardingInfo));
      console.log("OnboardingInfo postgraduation",onboardingInfo);

      const postData = JSON.stringify({
        "purpose": userinfoparsed.purpose,
        "fullName": userinfoparsed.fullName,
        "branch": "Medical",
        "course": {   
          "name": userinfoparsed.name,           
          "country": country,
          "state": statevalue,
          "college": collegevalue,
          "year": yearvalue
          
        }      
      });

      const response = await fetch(`${BASE_URL}/onboard/OnboardingData`, {
        method: "POST",
        headers: {
          'Authorization': 'Bearer ' +parsed.IdToken,  
          'Accept': 'application/json',
          'Content-Type': 'application/json',  
        },
        body: postData
      });

      const json = await response.json();
      console.log("json",json); 
      navigation.navigate("Personalised",{
        paramKey: onboardingInfo.fullName
      })       

    } catch (error) {
      console.error(error);
      return false;
    }
  }
  

  //route.params.paramKey1
  const [open, setOpen] = useState(false);
  const [statevalue, setStateValue] = useState(null);
  const [items, setItems] = useState([
    { label: "Karnataka", value: "KA" },
  ]);

  //route.params.paramKey2
  const [collegeopen, setCollegeOpen] = useState(false);
  const [collegevalue, setCollegeValue] = useState(null);
  const [collegeitems, setCollegeItems] = useState([]);

  //route.params.paramKey3
  const [yearopen, setYearOpen] = useState(false);
  const [yearvalue, setYearValue] = useState(null);
  const [yearitems, setYearItems] = useState([] as any);

//TO make the other dropdwons close while the other is open
  const onStateOpen = useCallback(() => {
        setCollegeOpen(false);
        setYearOpen(false);
  }, []);

  const onCollegeOpen = useCallback(() => {
        setYearOpen(false);
        setOpen(false);
  }, []);

  const onyearOpen = useCallback(() => {
    setCollegeOpen(false);
    setOpen(false);
}, []);

  return (
    <Container>
      <View style={styles.topading}>
        <SafeAreaView style={styles.content}>
          <RadioButtonGroup
            containerStyle={{ marginBottom: 0 }}
            selected={country}
            onSelected={(radiovalue : string) =>{
              setCountry(radiovalue);
              if(radiovalue == "IN"){
                getStateData()
              }             
              
            }}
            containerOptionStyle={{ margin: 8 }}
            radioBackground="#fff"
            radioStyle={{
              backgroundColor: "#777BD1",
              borderWidth: 5,
              borderColor: "#777BD1",
              opacity: 1,
            }}
            size={26}
          >
            <RadioButtonItem
              value="IN"
              label={<Text style={styles.label}>PG from India</Text>}
            />
            <RadioButtonItem
              value="AB"
              label={<Text style={styles.label}>PG from Abroad</Text>}
            />
          </RadioButtonGroup>
        </SafeAreaView>
        <Text style={styles.subheading}>State, Collage, Year</Text>

        <View style={[styles.seltwrap]}>          
          <View style={[country ?  styles.without1 :  styles.with1]}>
          <View style={[country ? styles.nooverlay1 : styles.overlay1]}></View>
          <DropDownPicker
            open={open}
            value={statevalue}
            items={items}
            setOpen={setOpen}
            setValue={setStateValue}
            setItems={setItems}
            itemKey="value"
            zIndex={3000}
            zIndexInverse={1000}
            placeholder="State"
            closeAfterSelecting={true}
            onOpen={onStateOpen}
            onChangeValue={(value :string) => {
              console.log(value);
              collegeData(value)
            }}
            disabledStyle={{
              opacity: 0.4
            }}
            style={{
              backgroundColor: "#18191C",
              height: 60,
              paddingLeft: 20,
              borderRadius: 12,
            }}
            arrowIconStyle={{
              width: 30,
              height: 30,
            }}
            listMode="SCROLLVIEW"
            scrollViewProps={{
            nestedScrollEnabled: true,
            }}
            dropDownContainerStyle={{
              padding: 10,
              position: 'relative', 
              top: 0,
            }}
            textStyle={{
              fontSize: 16,
              color: "#6E7191",
              fontFamily: "RobotoMedium",
            }}
          />
          </View>
          <View style={styles.space}></View>
          <View style={[statevalue ?  styles.without2 :  styles.with2]}>
          <View style={[statevalue ? styles.nooverlay2 : styles.overlay2]}></View>
          <DropDownPicker
            open={collegeopen}
            value={collegevalue}
            items={collegeitems}
            setOpen={setCollegeOpen}
            setValue={setCollegeValue}
            setItems={setCollegeItems}
            zIndex={2000}
            zIndexInverse={2000}
            itemKey="value"
            placeholder="Collage"
            closeAfterSelecting={true}
            onOpen={onCollegeOpen}
            onChangeValue={() => {
              yearData()
            }}
            listMode="SCROLLVIEW"
            scrollViewProps={{
            nestedScrollEnabled: true,
            }}
            style={{
              backgroundColor: "#18191C",
              height: 60,
              paddingLeft: 20,
              borderRadius: 12,
            }}
            arrowIconStyle={{
              width: 30,
              height: 30,
            }}
            dropDownContainerStyle={{
              backgroundColor: "#18191C",
              padding: 10,
              position: 'relative', 
              top: 0,
            }}
            textStyle={{
              fontSize: 16,
              color: "#6E7191",
              fontFamily: "RobotoMedium",
            }}
            contentContainerStyle={{ flexGrow: 1 }}
          />
          </View>
          <View style={styles.space}></View>
          <View style={[collegevalue ?  styles.without3 :  styles.with3]}>
          <View style={[collegevalue ? styles.nooverlay3 : styles.overlay3]}></View>
          <DropDownPicker
            open={yearopen}
            value={yearvalue}
            items={yearitems}
            setOpen={setYearOpen}
            setValue={setYearValue}
            setItems={setYearItems}
            zIndex={1000}
            zIndexInverse={3000}
            itemKey="value"
            placeholder="Year of study"
            closeAfterSelecting={true}
            onOpen={onyearOpen}
            style={{
              backgroundColor: "#18191C",
              height: 60,
              paddingLeft: 20,
              borderRadius: 12,
            }}
            arrowIconStyle={{
              width: 30,
              height: 30,
            }}
            listMode="SCROLLVIEW"
            scrollViewProps={{
            nestedScrollEnabled: true,
            }}
            dropDownContainerStyle={{
              backgroundColor: "#18191C",
              padding: 10,
              position: 'relative', 
              top: 0,
            }}
            textStyle={{
              fontSize: 16,
              color: "#6E7191",
              fontFamily: "RobotoMedium",
            }}
          />
          </View>
        </View>

        <Pressable style={styles.btn} onPress={emptyCheck}>
          <Text style={styles.btnText}>Save</Text>
        </Pressable>
      </View>
    </Container>
  );
}

const styles = StyleSheet.create({
  topading: {
    paddingTop: 120,
    position: "relative",
    height: height,
  },
  title: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 27,
    textAlign: "center",
  },
  subheading: {
    fontFamily: "PoppinsRegular",
    color: "#FFF1E4",
    fontSize: 14,
    textAlign: "center",
    marginBottom: 25,
    marginTop: 60,
  },
  chalkimg: {
    width: 9,
    height: 28,
    position: "relative",
    left: 20,
  },
  yeloline: {
    width: 60,
    height: 4,
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 10,
  },
  whitetxt: {
    color: "#fff",
    textAlign: "center",
    fontSize: 24,
    fontFamily: "PoppinsRegular",
  },
  bold: {
    fontWeight: "bold",
  },
  cant: {
    paddingTop: 60,
  },
  takicon: {
    width: 20,
    height: 20,
    position: "relative",
    left: -10,
  },
  curvewrap: {
    textAlign: "right",
    marginTop: 40,
    marginBottom: 40,
    display: "flex",
    alignItems: "center",
  },
  curve: {
    width: 80,
    height: 61,
    alignSelf: "flex-end",
    marginRight: 40,
  },
  content: {
    alignSelf: "stretch",
    padding: 20,
    backgroundColor: "#18191C",
    margin: 20,
    marginBottom: 0,
    borderRadius: 16,
  },
  selectbox: {
    marginBottom: 24,
    paddingLeft: 20,
    paddingRight: 20,
    marginRight: 20,
    width: "100%",
  },
  frmlabel: {
    color: "#FFF1E4",
    fontFamily: "PoppinsRegular",
    fontSize: 14,
    padding: 20,
  },
  label: {
    color: "#6E7191",
    fontSize: 15,
    fontFamily: "PoppinsSemiBold",
    paddingLeft: 10,
  },
  btn: {
    backgroundColor: "#787bd1",
    marginTop: 30,
    height: 50,
    borderRadius: 12,
    width: 280,
    textAlign: "center",
    marginLeft: "auto",
    marginRight: "auto",
    position: "absolute",
    left: width / 2 - 140,
    bottom: 0,
  },
  btnText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "bold",
    paddingTop: 15,
  },
  seltwrap: {
    paddingLeft: 20,
    paddingRight: 20
  },
  with1:{
    opacity:0.5,
    position:"relative", 
  },
  without1:{
    opacity:1,
    position:"relative",
    zIndex:1000
  },
  with2:{
    opacity:0.5,
    position:"relative", 
  },
  without2:{
    opacity:1,
    position:"relative",
    zIndex:100
  },
  with3:{
    opacity:0.5,
    position:"relative", 
  },
  without3:{
    opacity:1,
    position:"relative",
    zIndex:10
  },
  overlay1:{
    position:"absolute",
    width:"100%",
    height:"100%",
    zIndex:10000,
  },
  nooverlay1:{
    position:"relative",
    zIndex:0  
  },
  overlay2:{
    position:"absolute",
    width:"100%",
    height:"100%",
    zIndex:10000, 
  },
  nooverlay2:{
    position:"relative",
    zIndex:0  
  },
  overlay3:{
    position:"absolute",
    width:"100%",
    height:"100%",
    zIndex:10000, 
  },
  nooverlay3:{
    position:"relative",
    zIndex:0  
  },
  without:{
    opacity:1,
    position:"relative"
  },
 
  space: {
    height: 20,
  },
});
