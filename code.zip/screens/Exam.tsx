import React, { useState } from "react";
import {
  Dimensions,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  View,
} from "react-native";

import Container from "@components/Container";

import RadioButtonGroup, { RadioButtonItem } from "expo-radio-button";

const width = Dimensions.get("window").width; //full width
const height = Dimensions.get("window").height; //full height

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function Branch({ navigation }: { navigation: any }) {
  const [currentfirst, setCurrentFirst] = useState("branchfirst");

  const [currentsecond, setCurrentSecond] = useState("branchsecond");

  // const state = {
  //   checked: "first",
  // };

  const Homescrn = () => {
    navigation.navigate("PostGraduation");
  };

  // const name = "Maalty";
  return (
    <Container>
      {/* <Pressable style={styles.btn} onPress={Homescrn}>
        <Text style={styles.btnText}>Skip</Text>
      </Pressable> */}

      <View style={styles.topading}>
        <SafeAreaView style={styles.content}>
          <Text style={styles.frmlabel}>Please select the Branch </Text>

          <RadioButtonGroup
            containerStyle={{ marginBottom: 0 }}
            selected={currentfirst}
            onSelected={(value: React.SetStateAction<string>) =>
              setCurrentFirst(value)
            }
            containerOptionStyle={{ marginTop: 14 }}
            radioBackground="#fff"
            radioStyle={{
              backgroundColor: "#777BD1",
              borderWidth: 5,
              borderColor: "#777BD1",
              opacity: 1,
            }}
            size={26}
          >
            <RadioButtonItem
              value="medical"
              label={<Text style={styles.label}>Medical</Text>}
            />
            <RadioButtonItem
              value="engineering"
              label={<Text style={styles.label}>Engineering</Text>}
            />
          </RadioButtonGroup>
        </SafeAreaView>

        <SafeAreaView style={styles.content}>
          <Text style={styles.frmlabel}>Please select the Branch </Text>

          <RadioButtonGroup
            containerStyle={{ marginBottom: 0 }}
            selected={currentsecond}
            onSelected={(value: React.SetStateAction<string>) =>
              setCurrentSecond(value)
            }
            containerOptionStyle={{ marginTop: 14 }}
            radioBackground="#fff"
            radioStyle={{
              backgroundColor: "#777BD1",
              borderWidth: 5,
              borderColor: "#777BD1",
              opacity: 1,
            }}
            size={26}
          >
            <RadioButtonItem
              value="medical_pg"
              label={<Text style={styles.label}>Medical PG</Text>}
            />
            <RadioButtonItem
              value="ss_surgery"
              label={<Text style={styles.label}>SS Surgery</Text>}
            />
            <RadioButtonItem
              value="ss_medicine"
              label={<Text style={styles.label}>SS Medicine</Text>}
            />
            <RadioButtonItem
              value="fmge"
              label={<Text style={styles.label}>FMGE</Text>}
            />
            <RadioButtonItem
              value="neet_ug"
              label={<Text style={styles.label}>NEET UG</Text>}
            />
          </RadioButtonGroup>
        </SafeAreaView>

        <Pressable style={styles.btn} onPress={Homescrn}>
          <Text style={styles.btnText}>Proceed</Text>
        </Pressable>
      </View>
    </Container>
  );
}

const styles = StyleSheet.create({
  topading: {
    paddingTop: 120,
    flexDirection: "column",
    justifyContent: "flex-start",
    position: "relative",
    height: height,
  },
  title: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 27,
    textAlign: "center",
  },
  chalkimg: {
    width: 9,
    height: 28,
    position: "relative",
    left: 20,
  },
  yeloline: {
    width: 60,
    height: 4,
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 10,
  },
  whitetxt: {
    color: "#fff",
    textAlign: "center",
    fontSize: 24,
    fontFamily: "PoppinsRegular",
  },
  bold: {
    fontWeight: "bold",
  },
  cant: {
    paddingTop: 60,
  },
  takicon: {
    width: 20,
    height: 20,
    position: "relative",
    left: -10,
  },
  curvewrap: {
    textAlign: "right",
    marginTop: 40,
    marginBottom: 40,
    display: "flex",
    alignItems: "center",
  },
  curve: {
    width: 80,
    height: 61,
    alignSelf: "flex-end",
    marginRight: 40,
  },
  content: {
    alignSelf: "stretch",
    padding: 20,
    backgroundColor: "#18191C",
    margin: 20,
    marginBottom: 0,
    borderRadius: 16,
  },
  frmlabel: {
    color: "#FFF1E4",
    fontFamily: "PoppinsRegular",
    fontSize: 14,
  },
  label: {
    color: "#6E7191",
    fontSize: 15,
    fontFamily: "PoppinsSemiBold",
    paddingLeft: 10,
  },
  btn: {
    backgroundColor: "#787bd1",
    marginTop: 30,
    height: 50,
    borderRadius: 12,
    width: 280,
    textAlign: "center",
    marginLeft: "auto",
    marginRight: "auto",
    position: "absolute",
    left: width / 2 - 140,
    bottom: 0,
  },
  btnText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "bold",
    paddingTop: 15,
  },
  alignment: {
    display: "flex",
    justifyContent: "flex-start",
  },
});
