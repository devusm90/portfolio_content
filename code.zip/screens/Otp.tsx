import Container from "@components/Container";
import { BASE_URL } from "@env";
import AsyncStorage from '@react-native-async-storage/async-storage';
import OTPInputView from '@twotalltotems/react-native-otp-input';
import React, { useState } from "react";
import {
  Image,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  View
} from "react-native";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function Otp({ navigation}: { navigation: any}) {

  // const [invalidCode, setInvalidCode] = useState(false);
  // const [invalidCode, setInvalidCode] = useState('');
  const [otp, setOtp] = useState('');
  const userInfo = {  
    AccessToken: "",  
    IdToken: "",
    RefreshToken: ""
}  

  // const createAccount = () => {
  //   navigation.navigate("YourName");
  // };

 const verifyOTP = async (code:string) => {
    try {
      const jsonValue = await AsyncStorage.getItem('completeUserData') as string
      const parsed = JSON.parse(jsonValue);
      if(parsed !== null) {
        // console.log("parsed",parsed);
        // console.log("jsonValue",jsonValue);
        // console.log("otp",otp);
      }


      const data = JSON.stringify({
        user_name: parsed.user_id,
        session: parsed.session_id,
        answer: code
      });

      // console.log("data",data);
   
      const response = await fetch(`${BASE_URL}/verify/verifyotp`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: data,
      });

      
   
      const json = await response.json();

      const accessToken = json.AccessToken;
      const idToken = json.IdToken;
      const refreshToken = json.RefreshToken;

      if (json) {       
        userInfo.AccessToken = accessToken;
        userInfo.IdToken = idToken;
        userInfo.RefreshToken = refreshToken;
        await AsyncStorage.setItem('UserInfo', JSON.stringify(userInfo));
          // console.log("userInfo",userInfo); 
      }else {
          alert('Please fill data');
      }

      if(json.success){
        // getUserInfo()
      }
      return json.success;
      
    } catch (error) {
      console.error(error);
      return false;
    } 

    
  };

  const getUserInfo = async () => {
    try {
      const jsonValue = await AsyncStorage.getItem('UserInfo') as string
      const parsed = JSON.parse(jsonValue);      
      if(parsed !== null) {
        // console.log("parsed",parsed);
        // console.log("jsonValue",jsonValue);
      }

      // const data = JSON.stringify({
      //   idToken: parsed.IdToken,
      // });    

      const response = await fetch(`${BASE_URL}/onboard/OnboardingData`, {
        method: "GET",
        headers: {
          'Authorization': 'Bearer ' +parsed.IdToken,  
          'Accept': 'application/json',
          'Content-Type': 'application/json',   
          
        },
        body: ""
      });

      const json = await response.json();  
        
      return json.success;
    } catch (error) {
      console.error(error);
      return false;
    }
    
  };


  return (
    <Container>
      <View style={styles.container}>
        <View style={styles.top}>
          <Text style={styles.title}>Enter OTP</Text>
          <Text style={styles.subtitle}>
            Enter the OTP sent to you just now
          </Text>
          <View>
            <Image
              style={styles.yeloline}
              source={require("@assets/images/yellow-line.png")}
            />
            <Image
              style={styles.otpimg}
              source={require("@assets/images/otp-img.png")}
            />
            <Image
              style={styles.arrow}
              source={require("@assets/images/arrow.png")}
            />
          </View>
        </View>
        <View style={styles.bottom}>
          <SafeAreaView style={styles.content}>
            {/* <View style={styles.otpWrap}>
              <TextInput style={styles.input} placeholderTextColor="#6E7191" />
              <TextInput style={styles.input} placeholderTextColor="#6E7191" />
              <TextInput style={styles.input} placeholderTextColor="#6E7191" />
              <TextInput style={styles.input} placeholderTextColor="#6E7191" />
            </View> */}
            <OTPInputView
              style={{ width: "100%", height: 50,paddingRight:45,paddingLeft:45,  display:"flex",justifyContent:"space-between",flexDirection:"row",alignItems:"center" }}
              pinCount={4}
              code={otp}
              autoFocusOnLoad
              codeInputFieldStyle={styles.input}
              codeInputHighlightStyle={styles.underlineStyleHighLighted}
              keyboardType={"number-pad"}
              onCodeChanged={val => setOtp(val)}
              onCodeFilled={(code) => {
                verifyOTP(code).then(() => {
                  if(userInfo.AccessToken != undefined){
                    console.log("success");
                    getUserInfo();
                    navigation.navigate("SelectPurpose");
                  }else{
                    console.log("not success");
                  }
                  // if (!success){                    
                  //   console.log("not success");
                  //   setInvalidCode(true);
                  // }else{
                  //   console.log("success");
                  //   navigation.navigate("PostGraduation");
                  // }
                });
                // console.log(`Code is ${code}, you are good to gocc!`)
              }}
            />
            {/* {invalidCode && <Text style={styles.error}>Incorrect code.</Text>} */}
            <Pressable style={styles.btn}>
              <Text style={styles.btnText}>Proceed</Text>
            </Pressable>

            <Text style={styles.resnd}>
              <Text>Resend in</Text>
              <Text style={styles.resndbold}> 50 Sec</Text>
            </Text>

            <Text
              style={styles.cngeno}
              onPress={() => navigation.navigate("SignUp")}
            >
              Change Number
            </Text>
          </SafeAreaView>
        </View>
      </View>
    </Container>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "column",
  },
  top: {
    flex: 1.8,
  },
  bottom: {
    flex: 1,
    backgroundColor: "#18191C",
  },
  bgimage: {
    flex: 1,
    position: "absolute",
    width: "100%",
    height: "100%",
  },
  title: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 24,
    textAlign: "center",
    marginTop: 120,
    marginBottom: 10,
  },
  error: {
    color: "red",
  },
  subtitle: {
    fontSize: 14,
    color: "#FFF1E4",
    textAlign: "center",
    fontFamily: "PoppinsRegular",
  },
  yeloline: {
    width: 60,
    height: 4,
    marginLeft: "auto",
    marginRight: "auto",
    marginTop: 6,
  },
  otpimg: {
    marginTop: 30,
    width: 120,
    height: 123,
    marginLeft: "auto",
    marginRight: "auto",
  },
  arrow: {
    marginLeft: "auto",
    marginRight: "auto",
  },
  content: {
    alignSelf: "stretch",
    paddingTop: 26,
    backgroundColor: "#18191C",
    paddingBottom: 20,
  },
  otpWrap: {
    display: "flex",
    justifyContent: "center",
    flexDirection: "row",
  },
  input: {
    borderColor: "#6E7191",
    borderWidth: 1,
    backgroundColor: "#0B0B13",
    color: "red",
    height: 50,
    fontSize: 20,
    width: 60,
    marginLeft: 6,
    marginRight: 6,
    borderRadius: 10,
    textAlign: "center",
  },
  btn: {
    backgroundColor: "#787bd1",
    marginTop: 30,
    height: 50,
    borderRadius: 12,
    width: 280,
    textAlign: "center",
    marginLeft: "auto",
    marginRight: "auto",
  },
  btnText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "bold",
    paddingTop: 15,
  },
  resnd: {
    fontSize: 16,
    color: "#FFF1E4",
    textAlign: "center",
    fontFamily: "PoppinsRegular",
    marginTop: 20,
  },
  resndbold: {
    fontWeight: "bold",
    color: "#FCFCFC",
  },
  cngeno: {
    color: "#777BD1",
    textAlign: "center",
    marginTop: 20,
    fontSize: 16,
  },
  underlineStyleBase: {
    width: 30,
    height: 45,
    borderWidth: 0,
    borderBottomWidth: 1,
    color: "black",
    fontSize: 20,
  },
 
  underlineStyleHighLighted: {
    borderColor: "#03DAC6",
  },
 
});
