import BottomNav from "@components/BottomNav";
import Container from "@components/Container";
import React from "react";
import { ScrollView, StyleSheet, Text } from "react-native";





  
// eslint-disable-next-line no-unused-vars, @typescript-eslint/no-unused-vars, @typescript-eslint/no-explicit-any
export default function Revise({ navigation }: { navigation: any }) {

  return (
    <Container>
      <ScrollView>
        <Text style={styles.title}>Revise</Text>       
      </ScrollView>
      <BottomNav />
    </Container>
  );
}

const styles = StyleSheet.create({
  title: {
    fontFamily: "RecoletaBold",
    color: "#FFF1E4",
    fontSize: 27,
    textAlign: "center",
    marginTop: 120,
    marginBottom: 10,
  },
  container: {
    flex: 1,
    marginTop: 200,
  },
  item: {
    backgroundColor: '#f9c2ff',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
    width:380,
    height:400
  }
});
