import { CognitoHostedUIIdentityProvider } from "@aws-amplify/auth/lib/types";
import Container from "@components/Container";
import { BASE_URL } from "@env";
import AsyncStorage from '@react-native-async-storage/async-storage';
import config from "@src/aws-exports";
import { Amplify, Auth } from "aws-amplify";
import React, { useState } from "react";
import {
  Alert, Image,
  Pressable,
  SafeAreaView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from "react-native";

Amplify.configure(config);

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export default function SignUp({ navigation }: { navigation: any }) {
  
  const appleLogin = () => {
    alert("Apple Login");
  };

  // const [user, setUser] = useState(null);
  // const [customState, setCustomState] = useState(null);

  // useEffect(() => {
  //   const unsubscribe = Hub.listen("auth", ({ payload: { event, data } }) => {
  //     switch (event) {
  //       case "signIn":
  //         setUser(data);
  //         break;
  //       case "signOut":
  //         setUser(null);
  //         break;
  //       case "customOAuthState":
  //         setCustomState(data);
  //     }
  //   });

  //   Auth.currentAuthenticatedUser()
  //     .then(currentUser => setUser(currentUser))
  //     .catch(() => console.log("Not signed in"));

  //   return unsubscribe;
  // }, []);

  const [value, setValue] = useState("");
  // const [formattedValue, setFormattedValue] = useState("");
  // const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userDetails, setUserDetails] = useState({});
  // const [textInputValue, setTextInputValue] = useState('');




  const valueAlert = () =>
    Alert.alert('Field must not be empty', '', [      
      {text: 'OK', onPress: () => console.log('OK Pressed')},
    ]);

  const sendSmsVerification = async () => {
    
    // const verificationType = userDataValue.includes('@') === true ? 'email' : 'phone';

    // console.log(verificationType);     
    // console.log("value",value);     
               

    try {
      const validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;    
      const userDataValue = value;    
     
      const verificationType = userDataValue.match(validRegex) ? 'email' : 'phone';


      const data = JSON.stringify({
        attrType: verificationType,
        attrVal: value,
      });
   
      const response = await fetch(`${BASE_URL}/send/sendotp`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: data,
      });
   
      const json = await response.json();
      const userId = json.userID;
      const sessionId = json.session;

      console.log("response",response); 
      // console.log("session",json.session); 

      // setIsLoggedIn(true);
      setUserDetails({sessionId, userId});

      if (json) {
        const userDataObject = {  
          user_id: userId,  
          session_id: sessionId
        }         

        await AsyncStorage.setItem('completeUserData', JSON.stringify(userDataObject));
        // setIsLoggedIn(true);
        // setTextInputValue('');
        console.log("data saved"); 
     }else {
        alert('Please fill data');
     }
      return json.success;
    } catch (error) {
      console.error(error);
      return false;
    }
   };



  return (
    <Container>
      <View style={styles.container}>
        <View style={styles.top}>
          <Text style={styles.letText}>Hey there 👋🏼</Text>
          <Text style={styles.text}>
            Hop right in, we&apos;re in for a ride!
          </Text>
          <Image
            style={styles.signupimg}
            source={require("@assets/images/signup.png")}
          />
        </View>

        <View style={styles.bottom}>
          <SafeAreaView style={styles.content}>
            <TextInput
              style={styles.phNo}
              placeholder="Phone Number"
              placeholderTextColor="#6E7191"
              autoCapitalize={'none'}
              keyboardType="email-address"
              onChangeText={(text) => {
                setValue(text);                          
              }}              
            />
            <Pressable 
            style={styles.btn} 
            onPress={() => {              
              sendSmsVerification().then((sent) => {
                console.log("Sent!");
                if (value) {
                  navigation.navigate("Otp");
                } else {
                  valueAlert();
                }
                
              });
            }}
            >
            <Text style={styles.btnText}>Send OTP</Text>
            </Pressable>

            <Text style={styles.orText}>or sign in with</Text>

            <View style={styles.loginWrap}>
              <TouchableOpacity
                onPress={() =>
                  Auth.federatedSignIn({
                    provider: CognitoHostedUIIdentityProvider.Google,
                  })
                }
              >
                <Image
                  style={styles.glImg}
                  source={require("@assets/images/google.png")}
                />
              </TouchableOpacity>
              <Pressable style={styles.loginicon} onPress={appleLogin}>
                <Image
                  style={styles.aplImg}
                  source={require("@assets/images/apple.png")}
                />
              </Pressable>
            </View>
          </SafeAreaView>

          <SafeAreaView style={styles.prvcontent}>
            <Text style={styles.plcytext}>
              By signing up, you agree to our Terms of Service and
            </Text>
            <Text style={styles.plcytext}>
              acknowledge that our Privacy Policy applies to you.
            </Text>
          </SafeAreaView>
        </View>
      </View>
    </Container>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "column",
  },
  top: {
    flex: 1.35,
  },
  bottom: {
    flex: 1,
    backgroundColor: "#18191C",
  },
  content: {
    padding: 20,
    paddingTop: 26,
  },
  letText: {
    fontFamily: "RecoletaMedium",
    color: "#FFF1E4",
    fontSize: 32,
    textAlign: "center",
    marginTop: 120,
    marginBottom: 10,
  },
  text: {
    fontSize: 14,
    color: "#FFF1E4",
    textAlign: "center",
    fontFamily: "PoppinsRegular",
  },
  signupimg: {
    width: 380,
    height: 240,
    marginLeft: "auto",
    marginRight: "auto",
  },
  phNo: {
    borderColor: "#6E7191",
    borderWidth: 1,
    backgroundColor: "#0B0B13",
    color: "#fff",
    height: 50,
    fontSize: 16,
    width: 280,
    marginLeft: "auto",
    marginRight: "auto",
    borderRadius: 10,
    paddingLeft: 10,
  },
  btn: {
    backgroundColor: "#787bd1",
    marginTop: 20,
    height: 50,
    borderRadius: 12,
    width: 280,
    textAlign: "center",
    marginLeft: "auto",
    marginRight: "auto",
  },
  btnText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "bold",
    paddingTop: 15,
  },
  orText: {
    color: "#FFF1E4",
    fontSize: 16,
    padding: 20,
    textAlign: "center",
    fontFamily: "PoppinsRegular",
  },
  loginWrap: {
    display: "flex",
    justifyContent: "center",
    flexDirection: "row",
  },
  loginicon: {
    marginLeft: 16,
    marginRight: 16,
  },
  glImg: {
    width: 24,
    height: 24,
  },
  aplImg: {
    width: 19,
    height: 24,
  },
  plcytext: {
    fontSize: 10,
    color: "#777BD1",
    textAlign: "center",
  },
  prvcontent: {
    paddingTop: 20,
  },
});


