/* eslint-disable no-undef */
import { useNavigation, useNavigationState } from "@react-navigation/native";
import React, { useEffect, useState } from "react";
// import React, { useEffect, useState } from "react";
import { Image, Pressable, StyleSheet, Text, View } from "react-native";



export default function BottomNav() {
  const navigation = useNavigation();

  // const screenName = useNavigationState(state => state);
  // console.log('screenName: ',screenName);
  const routes = useNavigationState(state => state.routes);
  // const test = useNavigationState(state => state);  
  const currentRoute = routes[routes.length -1].name;
  // const path = routes[routes.length -1].path;
    // console.log('routes: ',routes);
  
  // const routesLength = navigation.getState().routes[routes.length -2];
  // console.log('routesLength: ',routesLength);

  // const str = window.location.pathname;
  // const pathname = str.split('/');
  // console.log('pathname1: ',pathname1);
  // console.log('pathname2: ',pathname2);
  // console.log('pathname3: ',pathname3);
  // console.log('pathname4: ',pathname4);
  console.log('currentRoute: ',currentRoute);
  // console.log('pathname: ',pathname[1]);


  
  // const str = window.location.pathname;
  // const pathname = str.replace('/', '');
  // console.log('pathname: ',pathname);
  const[toggle, setToggle] = useState(0);


  
  const switchToggle=()=>{
      // setCount(count+1)
      setToggle(current => !current);
  }

 
   <View style={toggle ? styles.switchnob : styles.activenob}></View>

  useEffect(() => {
   
    
    // const unsubscribe = navigation.addListener('focus', () => {
    //   alert("ff");
    // });

    // return unsubscribe;
   

  },[navigation]);

  const goHome = () => {
      navigation.navigate("Home");     
  };

  const goLearn = () => {
      navigation.navigate("Learn");
  };


  return (
    <View style={styles.btmnavwrap}>
      <Pressable style={styles.btmbtn} onPress={goHome}>
        <Image
          style={styles.icon}
          source={currentRoute == "Home" ? require("@assets/images/home_active.png") : require("@assets/images/home.png")}
        />
        <Text style={currentRoute == "Home" ? styles.red : styles.blue}>Home</Text>
      </Pressable>

      <Pressable style={styles.btmbtn} onPress={goLearn}>
        <Image
          style={styles.icon}
          source={currentRoute == "Learn" ? require("@assets/images/learn_active.png") : require("@assets/images/learn.png")}
        />
        <Text style={currentRoute == "Learn" ? styles.red : styles.blue}>Learn</Text>
      </Pressable>
      <Pressable
        style={styles.btmbtn}
        onPress={() => navigation.navigate("Revise")}
      >
        <Image
          style={styles.icon}
          source={currentRoute == "Revise" ? require("@assets/images/revice_active.png") : require("@assets/images/revice.png")}
        />
        <Text style={currentRoute == "Revise"  ? styles.red : styles.blue}>Revise</Text>
      </Pressable>
      <Pressable
        style={styles.btmbtn}
        onPress={() => navigation.navigate("Quiz")}
      >
        <Image
          style={styles.icon}
          source={currentRoute == "Quiz" ? require("@assets/images/quizicon_active.png") : require("@assets/images/quizicon.png")}
        />
        <Text style={currentRoute == "Quiz" ? styles.red : styles.blue}>Quiz</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  btmnavwrap: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingTop: 6,
    paddingLeft: 10,
    paddingRight: 10,
  },
  btmbtn: {
    padding: 6,
  },
  btnText: {
    color: "#fff",
    fontSize: 14,
    fontFamily: "PoppinsRegular",
  },
  icon: {
    width: 26,
    height: 26,
    marginLeft: "auto",
    marginRight: "auto",
  },
  red:{
    color:"#777BD1",
    fontSize: 14,
    fontFamily: "PoppinsRegular",
  },
  blue:{
    color:"#ffffff",
    fontSize: 14,
    fontFamily: "PoppinsRegular",
  }
});
