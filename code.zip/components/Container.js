/* eslint-disable no-undef */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import React, { Component } from "react";
import { ImageBackground, StyleSheet, View } from "react-native";

export default class Container extends Component {
  render() {
    const { style, children, ...props } = this.props;
    const cardStyles = [styles.card, style];

    return (
      <View style={styles.container}>
        <ImageBackground
          source={require("@assets/images/main-bg-full.png")}
          style={styles.bgimage}
        >
          <View style={styles.maincontent}>{children}</View>
        </ImageBackground>
      </View>
    );
  }
}

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0b0b13",
  },
  bgimage: {
    flex: 1,
  },
  maincontent: {
    flex: 1,
  },
});
