/* eslint-disable no-undef */
import { useNavigation } from "@react-navigation/native";
import React from "react";
import { Image, Pressable, StyleSheet, Text, View } from "react-native";

export default function HeaderNav() {
  const navigation = useNavigation();
  const goProfile = () => {
    navigation.navigate("Profile");
  };
  return (
    <View style={styles.homeouter}>    
    <View style={styles.premium}>
        <Image
          style={styles.diamond}
          source={require("@assets/images/diamond.png")}
        />  
        <Text style={styles.text}>Upgrade to premium</Text>
    </View>
    <View style={styles.hdrnavwrap}>
      <Pressable style={styles.btmbtn} onPress={goProfile}>
        <Image
          style={styles.userimg}
          source={require("@assets/images/user.png")}
        />
      </Pressable>
      <View style={styles.alglft}>
        <Pressable
          style={styles.btmbtn}
          onPress={() => navigation.navigate("Notification")}
        >
          <Image
            style={styles.notimg}
            source={require("@assets/images/notification.png")}
          />
        </Pressable>
        <Pressable
          style={styles.btmbtn}
          onPress={() => navigation.navigate("Search")}
        >
          <Image
            style={styles.srhimg}
            source={require("@assets/images/search.png")}
          />
        </Pressable>
      </View>
    </View>
    </View>
  );
}

export const styles = StyleSheet.create({
  premium:{
    backgroundColor:"#62D4A1",
    paddingTop:5,
    paddingBottom:5,
    display:"flex",
    justifyContent:"center",
    textAlign:"center",
    position:"absolute",
    flexDirection:"row",
    alignItems:"center",
    top:0,
    width:"100%"
  },
  diamond:{
    width:11,
    height:10,
    marginRight:10
  },
  homeouter:{

  },
  text:{
    color:"#000000",
    fontSize:12,
    width:150
  },
  hdrnavwrap: {
    marginTop: 50,
    flexDirection: "row",
    justifyContent: "space-between",
    paddingLeft: 10,
    paddingRight: 10,
    paddingBottom: 10,
  },
  btmbtn: {
    paddingLeft: 10,
    paddingRight: 10,
  },
  btnText: {
    color: "#fff",
    fontSize: 14,
    fontFamily: "PoppinsRegular",
  },
  alglft: {
    flexDirection: "row",
  },
  userimg: {
    width: 36,
    height: 36,
    borderRadius: 30,
  },
  notimg: {
    width: 27,
    height: 24,
    marginTop: 6,
  },
  srhimg: {
    width: 24,
    height: 24,
    marginTop: 4,
  },
});
