import { DefaultTheme, NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import React from "react";
import "react-native-gesture-handler";




import Branch from "@screens/Branch";
import Congratulations from "@screens/Congratulations";
import Exam from "@screens/Exam";
import Flashcards from "@screens/flashcard/Flashcards";
import Flashlist from "@screens/flashcard/Flashlist";
import Flashsub from "@screens/flashcard/Flashsub";
import Home from "@screens/Home";
import Notification from "@screens/Notification";
import Otp from "@screens/Otp";
import Personalised from "@screens/Personalised";
import PostGraduation from "@screens/PostGraduation";
import Learn from "@screens/qbank/Learn";
import QbankCongrat from "@screens/qbank/QbankCongrat";
import QbankMain from "@screens/qbank/QbankMain";
import QuestionMcq from "@screens/qbank/QuestionMcq";
import SolveMcq from "@screens/qbank/SolveMcq";
import Streak from "@screens/qbank/Streak";
import Revise from "@screens/Revise";
import Search from "@screens/Search";
import SelectPurpose from "@screens/SelectPurpose";
import SignUp from "@screens/SignUp";
import Tests from "@screens/tests/Tests";
import TestsCongrat from "@screens/tests/TestsCongrat";
import TestsQuestion from "@screens/tests/TestsQuestion";
import TestSubmit from "@screens/tests/TestSubmit";
import TestSubTopic from "@screens/tests/TestSubTopic";
import Welcome from "@screens/Welcome";
import YourName from "@screens/YourName";

import Quiz from "@screens/quiz/Quiz";
import QuizExplore from "@screens/quiz/QuizExplore";
import QuizRules from "@screens/quiz/QuizRules";

import OverallProgress from "@screens/OverallProgress";
import Profile from "@screens/Profile";
import ProfileAll from "@screens/ProfileAll";



const Stack = createNativeStackNavigator();
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const forFade = ({ current }: any) => ({
  cardStyle: {
    opacity: current.progress,
  },
});

const MyTheme = {
  ...DefaultTheme,
  colors: {
    ...DefaultTheme.colors,
    background: "#0b0b13",
  },
};





const linking = {
  prefixes: ["peoplesapp://"],
  config: {
    initialRouteName: "welcome",
    screens: {
      Welcome: {
        path: "welcome",
      },
      SignUp: {
        path: "signup",
      },
      Otp: {
        path: "otp",
      },
      SelectPurpose: {
        path: "selectpurpose",
      },
      YourName: {
        path: "yourname",
      },
      Branch: {
        path: "branch",
      },
      Exam: {
        path: "exam",
      },
      PostGraduation: {
        path: "postgraduation",
      },
      Personalised: {
        path: "personalised",
      },
      Home: {
        path: "home",
      },
      Learn: {
        path: "learn",
      },
      QbankMain: {
        path: "learn/qbank/qbankmain",
      },
      SolveMcq: {
        path: "learn/qbank/solvemcq",
      },
      QuestionMcq: {
        path: "learn/qbank/questionmcq",
      },
      Streak: {
        path: "learn/qbank/streak",
      },
      QbankCongrat: {
        path: "learn/qbank/qbankcongrat",
      },
      Flashcards: {
        path: "learn/flashcards",
      },
      Flashlist: {
        path: "learn/flashcards/flashlist",
      },
      Flashsub: {
        path: "learn/flashcards/flashsub",
      },
      Tests: {
        path: "learn/tests",
      },
      OverallProgress: {
        path: "learn/tests/overallprogress",
      },
      TestSubTopic: {
        path: "learn/tests/testsubTopic",
      },
      TestsQuestion: {
        path: "learn/tests/testsquestion",
      },
      TestSubmit: {
        path: "learn/tests/testsubmit",
      },
      TestsCongrat: {
        path: "learn/tests/testscongrat",
      },
      Revise: {
        path: "revise",
      },
      Quiz: {
        path: "quiz",
      },
      QuizExplore: {
        path: "quiz/quizexplore",
      },
      QuizRules: {
        path: "quiz/quizrules",
      },
      Notification: {
        path: "notification",
      },
      Search: {
        path: "search",
      },
    },
  },
};

export default function StackNav() {  

  return (
    <NavigationContainer theme={MyTheme} linking={linking}>
      <Stack.Navigator initialRouteName="Welcome">
        <Stack.Screen
          name="Welcome"
          component={Welcome}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="SignUp"
          component={SignUp}
          options={{ cardStyleInterpolator: forFade, headerShown: false }}
        />

        <Stack.Screen
          name="Otp"
          component={Otp}
          options={{
            cardStyleInterpolator: forFade,
            headerTitle: "Create Account",
            headerTitleAlign: "center",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />
        <Stack.Screen
          name="SelectPurpose"
          component={SelectPurpose}
          options={{
            cardStyleInterpolator: forFade,
            headerTitle: "Select Purpose",
            headerTitleAlign: "center",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />
        <Stack.Screen
          name="YourName"
          component={YourName}
          options={{
            cardStyleInterpolator: forFade,
            headerTitle: "Your Name",
            headerTitleAlign: "center",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />

        <Stack.Screen
          name="Branch"
          component={Branch}
          options={{
            cardStyleInterpolator: forFade,
            headerTitle: "Your Name",
            headerTitleAlign: "center",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />
        <Stack.Screen
          name="Exam"
          component={Exam}
          options={{
            cardStyleInterpolator: forFade,
            headerTitle: "Create Account",
            headerTitleAlign: "center",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />

        <Stack.Screen
          name="PostGraduation"
          component={PostGraduation}
          options={{
            cardStyleInterpolator: forFade,
            headerTitle: "Post Graduation Details",
            headerTitleAlign: "center",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />
        <Stack.Screen
          name="Personalised"
          component={Personalised}
          options={{ cardStyleInterpolator: forFade, headerShown: false }}
        />

        <Stack.Screen
          name="Home"
          component={Home}
          options={{
            cardStyleInterpolator: forFade,
            headerTitle: " ",
            headerTitleAlign: "center",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />

        <Stack.Screen
          name="Learn"
          component={Learn}
          options={{ cardStyleInterpolator: forFade, headerShown: false }}
        />
        <Stack.Screen
          name="QbankMain"
          component={QbankMain}
          options={{
            cardStyleInterpolator: forFade,
            headerTitle: "",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
          }}
        />
        <Stack.Screen
          name="SolveMcq"
          component={SolveMcq}
          options={{
            cardStyleInterpolator: forFade,
            headerTitle: "",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
          }}
        />
        <Stack.Screen
          name="QuestionMcq"
          component={QuestionMcq}
          options={{
            cardStyleInterpolator: forFade,
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="Streak"
          component={Streak}
          options={{
            cardStyleInterpolator: forFade,
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="QbankCongrat"
          component={QbankCongrat}
          options={{
            cardStyleInterpolator: forFade,
            headerTitle: "",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
          }}
        />

        <Stack.Screen
          name="Flashcards"
          component={Flashcards}
          options={{ cardStyleInterpolator: forFade, headerShown: false }}
        />
        <Stack.Screen
          name="Flashlist"
          component={Flashlist}
          options={{ cardStyleInterpolator: forFade, headerShown: false }}
        />
        <Stack.Screen
          name="Flashsub"
          component={Flashsub}
          options={{ cardStyleInterpolator: forFade, headerShown: false }}
        />
        <Stack.Screen
          name="Tests"
          component={Tests}
          options={{ cardStyleInterpolator: forFade, headerShown: false }}
        />
        <Stack.Screen
          name="OverallProgress"
          component={OverallProgress}
          options={{
            cardStyleInterpolator: forFade,
            headerShown: true,
            headerTitle: "Overall Progress",
            headerTitleAlign: "center",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />
        <Stack.Screen
          name="TestSubTopic"
          component={TestSubTopic}
          options={{
            cardStyleInterpolator: forFade,
            headerTitle: "Test SubTopic",
            headerTitleAlign: "center",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />
        <Stack.Screen
          name="TestsQuestion"
          component={TestsQuestion}
          options={{
            cardStyleInterpolator: forFade,
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="TestSubmit"
          component={TestSubmit}
          options={{
            cardStyleInterpolator: forFade,
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="TestsCongrat"
          component={TestsCongrat}
          options={{
            cardStyleInterpolator: forFade,
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="Revise"
          component={Revise}
          options={{
            cardStyleInterpolator: forFade,
            headerTitle: "Revise",
            headerTitleAlign: "center",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />
        <Stack.Screen
          name="Quiz"
          component={Quiz}
          options={{
            cardStyleInterpolator: forFade,
            headerTitle: "Quiz",
            headerTitleAlign: "center",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />
        <Stack.Screen
          name="QuizExplore"
          component={QuizExplore}
          options={{
            cardStyleInterpolator: forFade,
            headerTitle: "Quiz Explore",
            headerTitleAlign: "center",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />
        <Stack.Screen
          name="QuizRules"
          component={QuizRules}
          options={{
            cardStyleInterpolator: forFade,
            headerTitle: "Quiz Rules",
            headerTitleAlign: "center",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />
        <Stack.Screen
          name="Notification"
          component={Notification}
          options={{
            headerTitle: "Notification",
            headerTitleAlign: "center",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />
        <Stack.Screen
          name="Search"
          component={Search}
          options={{
            headerTitle: "Search",
            headerTitleAlign: "center",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />
        <Stack.Screen
          name="Profile"
          component={Profile}
          options={{
            headerShown: false,
          }}
        />
        <Stack.Screen
          name="ProfileAll"
          component={ProfileAll}
          options={{
            headerTitle: "",
            headerTitleAlign: "",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />
        <Stack.Screen
          name="Congratulations"
          component={Congratulations}
          options={{
            headerTitle: "",
            headerTitleAlign: "",
            headerTransparent: true,
            headerTintColor: "#FFF1E4",
            headerTitleStyle: {
              fontWeight: "400",
              fontFamily: "PoppinsRegular",
              fontSize: 16,
            },
          }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
