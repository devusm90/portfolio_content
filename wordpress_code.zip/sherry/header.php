<?php
/**
 * The header.
 *
 * This is the template that displays all of the <head> section and everything up until main.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Sherry_Papers
 * @since Sherry Papers 1.0
 */

?>
<!doctype html>
<html <?php language_attributes(); ?> <?php sherrypapers_the_html_classes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>


<!--Begin header section-->
<div class="header-container"> 
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="logo">
                    <a href="#">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.png" alt="Logo" title="Logo">
                    </a>
                </div>
                <div class="offcanvas-menu">
                    <div id="nav-icon3">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
                <div class="header-right">
                    <div class="logo">
                        <a href="#">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo.png" alt="Logo" title="Logo">
                        </a>
                    </div>
                    <div class="header-top">
                        <ul>
                            <li>
                                <img src="assets/images/svg/Phone.svg" alt="Phone">
                                <span>+91 0000 00 0000</span>
                            </li>
                            <li>
                                <img src="assets/images/svg/Messages.svg" alt="Mail">
                                <span>info@sherrypapers.com</span>
                            </li>
                        </ul>
                    </div>                        
                    <div class="main-menu">
                        <?php wp_nav_menu( array('menu' => 'Main Menu') ); ?>
                    </div>
                </div>                        
            </div>
        </div>
    </div>
</div>
<!--End header section-->