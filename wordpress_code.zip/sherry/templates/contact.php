<?php
/**
 * Template Name: Contact
 * Template Post Type: post, page
 *
 * @package WordPress
 * @subpackage Sherry_Papers
 * @since Sherry_Papers 1.0
 */

get_header(); ?>

<!--Begin Banner section-->
<section class="banner-container">
    <div class="owl-carousel owl-theme">
        <div class="item">
            <img src="assets/images/content/banner_2.png" alt="Banner">
            <div class="banner-content">
                <h2>SAY NO TO PLASTIC & SAVE OUR PLANET</h2>
                <span>ZERO PLASTIC = SAVE OUR PLANET</span>
            </div>
        </div> 
    </div>
</section>
<!--End Banner section-->

<div class="scondary-navbar">
    <div class="container">
        <div class="row">
            <ul class="nav">
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="#">Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link " aria-current="page" href="#">></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link " href="#">Contact Us</a>
                </li>
              </ul>
        </div>
    </div>
</div>

<!--Begin Content section-->
<section id="contact" class="product-container">
    <div class="container">
        <div class="row gx-5 ">
            <div class="col-md-6">
                <div class="contacts_content">
                    <h4>Find us on</h4>
                    <h5>Location</h5>
                    <h6>Sherry Speciality Papers Pvt Ltd, Vasai East, Mumbai</h6>
                    <h5>Email us</h5>
                    <h6>info@sherrypapers.com</h6>
                   
                    <h5>Contact us</h5>
                    <h6>+91 0000 00 0000</h6>
                    <h5>Follow us on</h5>
                   
                    <div class="icon">
                        <a href="">
                            <img src="assets/images/svg/linkedin_black.svg" alt="">
                        </a>
                        <a href="">
                            <img src="assets/images/svg/fb_black.svg" alt="">
                        </a>
                        <a href="">
                            <img src="assets/images/svg/twitter_black.svg" alt="">
                        </a>
                    </div>
                </div>                
            </div>
            <div class="col-md-6">
                <div class="map">
                    <img src="assets/images/content/banner_2.png" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<!--End Content section-->

<?php get_footer(); ?>
