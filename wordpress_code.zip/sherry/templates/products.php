<?php
/**
 * Template Name: Products page
 * Template Post Type: post, page
 *
 * @package WordPress
 * @subpackage Cctec
 * @since CCtec 1.0
 */

get_header();
?>


<div class="innerpage-banner">
    <!--Begin Banner section-->
    <section class="banner-container">
        <div class="banner-wrap">
            <?php the_post_thumbnail(); ?>  
        </div>

        <div class="banner-content">
            <div class="container">
                <div class="row">
                    <div class="col-sm-8 col-lg-8 col-xl-5">
                       <h1><?php the_title(); ?></h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Banner section-->
</div>



<div class="product-content">
    <div class="container">
        <div class="row d-flex">
            <div class="col-sm-6 align-self-center">
                <div class="product-left-content">
                    <h2><?php the_field("top_title"); ?></h2>
                    <p><?php the_field("top_content"); ?></p>
                </div>
            </div>
            <div class="col-sm-6">
                <?php if( get_field('top_image') ): ?>
                    <img src="<?php the_field('top_image'); ?>" />
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="product-list">
                    <div class="grid-sizer"></div>
                    <div class="gutter-sizer"></div>
                  <?php
                    $args = array(
                    'post_type'=> 'product',
                    'orderby'    => 'ID',
                    'post_status' => 'publish',
                    'order'    => 'DESC',
                    'posts_per_page' => -1 // this will retrive all the post that is published 
                    );
                    $result = new WP_Query( $args );
                    if ( $result-> have_posts() ) : 
                        $i=1;
                    ?>
                    <?php while ( $result->have_posts() ) : $result->the_post(); ?>

                    <div class="product-single with-bg<?php echo $i;?>">                        
                        <div class="product-text">
                            <h3><?php the_title(); ?></h3>
                            <?php the_content(); ?>
                            <ul>
                            <?php
                                if( have_rows('product_list') ):
                                    while ( have_rows('product_list') ) : the_row(); ?>

                                         <li>                                               
                                            <?php the_sub_field('sub_list'); ?>
                                        </li> 
                                 <?php       
                                    endwhile;
                                else :

                                endif; ?>  
                            </ul>
                        </div>
                    </div> 
                    <?php $i++; ?>
                    <?php endwhile; ?>
                    <?php endif; wp_reset_postdata(); ?>
            </div>
        </div>
    </div>
</div>



<?php get_footer(); ?>
