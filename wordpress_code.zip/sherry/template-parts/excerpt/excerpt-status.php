<?php
/**
 * Show the appropriate content for the Status post format.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Sherry_Papers
 * @since Sherry Papers 1.0
 */

// Print the full content.
the_content();
