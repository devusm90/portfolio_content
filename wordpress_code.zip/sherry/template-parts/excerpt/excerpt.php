<?php
/**
 * Show the excerpt.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Sherry_Papers
 * @since Sherry Papers 1.0
 */

the_excerpt();
