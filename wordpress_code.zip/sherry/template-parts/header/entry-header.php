<?php
/**
 * Displays the post header
 *
 * @package WordPress
 * @subpackage Sherry_Papers
 * @since Sherry Papers 1.0
 */

the_title( '<h1 class="entry-title">', '</h1>' );
