<?php /* 
This page is used to display the static frontpage. 
*/
 
get_header(); ?>


<!--Begin Banner section-->
<section class="banner-container">
    <div class="owl-carousel owl-theme">
        <div class="item">
            <img src="assets/images/content/banner_2.png" alt="Banner">
            <div class="banner-content">
                <h2>SAY NO TO PLASTIC & SAVE OUR PLANET</h2>
                <span>ZERO PLASTIC = SAVE OUR PLANET</span>
            </div>
        </div> 
    </div>
</section>
<!--End Banner section-->



<?php get_footer(); ?>