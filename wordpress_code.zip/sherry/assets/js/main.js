jQuery(function() {
        
/*===============================================
    Menu 
==================================================*/
    jQuery('.menu-icon').click(function () {
        jQuery(this).toggleClass('open');
        jQuery(".header-container").toggleClass('menu-open');
    });
    jQuery('.main-menu > ul li.has-ul > a').on( 'click', function () {
      jQuery(this).toggleClass('open');
      jQuery(this).parent().find(".submenu").slideToggle('slow');     
    });

    jQuery('#nav-icon3').click(function(){
        jQuery(this).toggleClass('open');
        jQuery("body").toggleClass("canvas-open");
    });


/*===============================================
    Sticky header
==================================================*/
    jQuery(window).scroll(function(){
        if (jQuery(this).scrollTop() > 50) {
           jQuery('.header-container').addClass('sticky');
        } else {
           jQuery('.header-container').removeClass('sticky');
        }
    });


/*===============================================
    Banner image height 
==================================================*/
    if (jQuery(".mobile-detect").is(":visible")) {
            
    } else {
        var header = jQuery(".header-container").height();        
        var wind = jQuery(window).height();    
        var newheight = wind - header;
        jQuery(".banner-container").height(newheight);
        jQuery(".banner-container .item").height(newheight);
    } 
    



/*===============================================
    Banner slider
==================================================*/
    jQuery('.owl-carousel').owlCarousel({
        loop:true,
        nav:false,
        dots:true,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:1
            },
            1000:{
                items:1
            }
        }
    })
    

    
});
