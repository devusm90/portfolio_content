<?php
/**
 * Block Styles
 *
 * @link https://developer.wordpress.org/reference/functions/register_block_style/
 *
 * @package WordPress
 * @subpackage Sherry_Papers
 * @since Sherry Papers 1.0
 */

if ( function_exists( 'register_block_style' ) ) {
	/**
	 * Register block styles.
	 *
	 * @since Sherry Papers 1.0
	 *
	 * @return void
	 */
	function sherry_papers_register_block_styles() {
		// Columns: Overlap.
		register_block_style(
			'core/columns',
			array(
				'name'  => 'sherrypapers-columns-overlap',
				'label' => esc_html__( 'Overlap', 'sherrypapers' ),
			)
		);

		// Cover: Borders.
		register_block_style(
			'core/cover',
			array(
				'name'  => 'sherrypapers-border',
				'label' => esc_html__( 'Borders', 'sherrypapers' ),
			)
		);

		// Group: Borders.
		register_block_style(
			'core/group',
			array(
				'name'  => 'sherrypapers-border',
				'label' => esc_html__( 'Borders', 'sherrypapers' ),
			)
		);

		// Image: Borders.
		register_block_style(
			'core/image',
			array(
				'name'  => 'sherrypapers-border',
				'label' => esc_html__( 'Borders', 'sherrypapers' ),
			)
		);

		// Image: Frame.
		register_block_style(
			'core/image',
			array(
				'name'  => 'sherrypapers-image-frame',
				'label' => esc_html__( 'Frame', 'sherrypapers' ),
			)
		);

		// Latest Posts: Dividers.
		register_block_style(
			'core/latest-posts',
			array(
				'name'  => 'sherrypapers-latest-posts-dividers',
				'label' => esc_html__( 'Dividers', 'sherrypapers' ),
			)
		);

		// Latest Posts: Borders.
		register_block_style(
			'core/latest-posts',
			array(
				'name'  => 'sherrypapers-latest-posts-borders',
				'label' => esc_html__( 'Borders', 'sherrypapers' ),
			)
		);

		// Media & Text: Borders.
		register_block_style(
			'core/media-text',
			array(
				'name'  => 'sherrypapers-border',
				'label' => esc_html__( 'Borders', 'sherrypapers' ),
			)
		);

		// Separator: Thick.
		register_block_style(
			'core/separator',
			array(
				'name'  => 'sherrypapers-separator-thick',
				'label' => esc_html__( 'Thick', 'sherrypapers' ),
			)
		);

		// Social icons: Dark gray color.
		register_block_style(
			'core/social-links',
			array(
				'name'  => 'sherrypapers-social-icons-color',
				'label' => esc_html__( 'Dark gray', 'sherrypapers' ),
			)
		);
	}
	add_action( 'init', 'sherry_papers_register_block_styles' );
}
